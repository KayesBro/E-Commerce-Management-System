﻿
namespace LoginForm
{
    partial class AddProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProductForm));
            this.lbProductId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbapfProductId = new System.Windows.Forms.TextBox();
            this.tbapfStock = new System.Windows.Forms.TextBox();
            this.tbapfPName = new System.Windows.Forms.TextBox();
            this.tbapfCategory = new System.Windows.Forms.TextBox();
            this.tbapfPrice = new System.Windows.Forms.TextBox();
            this.tbapfDetails = new System.Windows.Forms.TextBox();
            this.btnapfAddProduct = new System.Windows.Forms.Button();
            this.btnapfBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbProductId
            // 
            this.lbProductId.AutoSize = true;
            this.lbProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProductId.Location = new System.Drawing.Point(279, 39);
            this.lbProductId.Name = "lbProductId";
            this.lbProductId.Size = new System.Drawing.Size(105, 20);
            this.lbProductId.TabIndex = 0;
            this.lbProductId.Text = "Product ID :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(253, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product Name :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(293, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Category :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(322, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Price :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(244, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Stock Quantity :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(305, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Details :";
            // 
            // tbapfProductId
            // 
            this.tbapfProductId.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfProductId.Location = new System.Drawing.Point(397, 36);
            this.tbapfProductId.Name = "tbapfProductId";
            this.tbapfProductId.Size = new System.Drawing.Size(159, 26);
            this.tbapfProductId.TabIndex = 6;
            // 
            // tbapfStock
            // 
            this.tbapfStock.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfStock.Location = new System.Drawing.Point(397, 219);
            this.tbapfStock.Name = "tbapfStock";
            this.tbapfStock.Size = new System.Drawing.Size(159, 26);
            this.tbapfStock.TabIndex = 7;
            // 
            // tbapfPName
            // 
            this.tbapfPName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfPName.Location = new System.Drawing.Point(397, 83);
            this.tbapfPName.Name = "tbapfPName";
            this.tbapfPName.Size = new System.Drawing.Size(159, 26);
            this.tbapfPName.TabIndex = 8;
            // 
            // tbapfCategory
            // 
            this.tbapfCategory.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfCategory.Location = new System.Drawing.Point(397, 129);
            this.tbapfCategory.Name = "tbapfCategory";
            this.tbapfCategory.Size = new System.Drawing.Size(159, 26);
            this.tbapfCategory.TabIndex = 9;
            // 
            // tbapfPrice
            // 
            this.tbapfPrice.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfPrice.Location = new System.Drawing.Point(397, 175);
            this.tbapfPrice.Name = "tbapfPrice";
            this.tbapfPrice.Size = new System.Drawing.Size(159, 26);
            this.tbapfPrice.TabIndex = 10;
            // 
            // tbapfDetails
            // 
            this.tbapfDetails.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbapfDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbapfDetails.Location = new System.Drawing.Point(397, 269);
            this.tbapfDetails.Name = "tbapfDetails";
            this.tbapfDetails.Size = new System.Drawing.Size(159, 26);
            this.tbapfDetails.TabIndex = 11;
            // 
            // btnapfAddProduct
            // 
            this.btnapfAddProduct.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnapfAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnapfAddProduct.Location = new System.Drawing.Point(299, 352);
            this.btnapfAddProduct.Name = "btnapfAddProduct";
            this.btnapfAddProduct.Size = new System.Drawing.Size(97, 41);
            this.btnapfAddProduct.TabIndex = 12;
            this.btnapfAddProduct.Text = "Add Product";
            this.btnapfAddProduct.UseVisualStyleBackColor = false;
            this.btnapfAddProduct.Click += new System.EventHandler(this.btnapfAddProduct_Click);
            // 
            // btnapfBack
            // 
            this.btnapfBack.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnapfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnapfBack.Location = new System.Drawing.Point(459, 352);
            this.btnapfBack.Name = "btnapfBack";
            this.btnapfBack.Size = new System.Drawing.Size(97, 41);
            this.btnapfBack.TabIndex = 13;
            this.btnapfBack.Text = "Back";
            this.btnapfBack.UseVisualStyleBackColor = false;
            this.btnapfBack.Click += new System.EventHandler(this.btnapfBack_Click);
            // 
            // AddProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(843, 481);
            this.Controls.Add(this.btnapfBack);
            this.Controls.Add(this.btnapfAddProduct);
            this.Controls.Add(this.tbapfDetails);
            this.Controls.Add(this.tbapfPrice);
            this.Controls.Add(this.tbapfCategory);
            this.Controls.Add(this.tbapfPName);
            this.Controls.Add(this.tbapfStock);
            this.Controls.Add(this.tbapfProductId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbProductId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddProductForm";
            this.Text = "AddProductForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbProductId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbapfProductId;
        private System.Windows.Forms.TextBox tbapfStock;
        private System.Windows.Forms.TextBox tbapfPName;
        private System.Windows.Forms.TextBox tbapfCategory;
        private System.Windows.Forms.TextBox tbapfPrice;
        private System.Windows.Forms.TextBox tbapfDetails;
        private System.Windows.Forms.Button btnapfAddProduct;
        private System.Windows.Forms.Button btnapfBack;
    }
}