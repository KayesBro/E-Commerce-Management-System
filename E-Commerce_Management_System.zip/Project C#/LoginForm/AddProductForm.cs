﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class AddProductForm : Form
    {
        public AddProductForm()
        {
            InitializeComponent();
        }

        Product p = new Product();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnapfBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        public void clear()
        {
            tbapfProductId.Clear();
            tbapfPName.Clear();
            tbapfCategory.Clear();
            tbapfPrice.Clear();
            tbapfStock.Clear();
            tbapfDetails.Clear();
        }
        private void btnapfAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                p.ProductID = tbapfProductId.Text;
                p.ProductName = tbapfPName.Text;
                p.Category = tbapfCategory.Text;
                p.Price = Convert.ToDouble(tbapfPrice.Text);
                p.StockQuantity = Convert.ToInt32(tbapfStock.Text);
                p.Details = tbapfDetails.Text;

            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = p.AddProduct(p);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }
    }
}
