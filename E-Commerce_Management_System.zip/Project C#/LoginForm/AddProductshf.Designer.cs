﻿
namespace LoginForm
{
    partial class AddProductshf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddProductshf));
            this.btnspfBack = new System.Windows.Forms.Button();
            this.btnspfAddProduct = new System.Windows.Forms.Button();
            this.tbspfDetails = new System.Windows.Forms.TextBox();
            this.tbspfPrice = new System.Windows.Forms.TextBox();
            this.tbspfCategory = new System.Windows.Forms.TextBox();
            this.tbspfPName = new System.Windows.Forms.TextBox();
            this.tbspfStock = new System.Windows.Forms.TextBox();
            this.tbspfProductId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbProductId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnspfBack
            // 
            this.btnspfBack.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnspfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnspfBack.Location = new System.Drawing.Point(373, 361);
            this.btnspfBack.Name = "btnspfBack";
            this.btnspfBack.Size = new System.Drawing.Size(97, 41);
            this.btnspfBack.TabIndex = 27;
            this.btnspfBack.Text = "Back";
            this.btnspfBack.UseVisualStyleBackColor = false;
            this.btnspfBack.Click += new System.EventHandler(this.btnspfBack_Click);
            // 
            // btnspfAddProduct
            // 
            this.btnspfAddProduct.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnspfAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnspfAddProduct.Location = new System.Drawing.Point(213, 361);
            this.btnspfAddProduct.Name = "btnspfAddProduct";
            this.btnspfAddProduct.Size = new System.Drawing.Size(97, 41);
            this.btnspfAddProduct.TabIndex = 26;
            this.btnspfAddProduct.Text = "Add Product";
            this.btnspfAddProduct.UseVisualStyleBackColor = false;
            this.btnspfAddProduct.Click += new System.EventHandler(this.btnspfAddProduct_Click);
            // 
            // tbspfDetails
            // 
            this.tbspfDetails.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfDetails.Location = new System.Drawing.Point(311, 278);
            this.tbspfDetails.Name = "tbspfDetails";
            this.tbspfDetails.Size = new System.Drawing.Size(159, 26);
            this.tbspfDetails.TabIndex = 25;
            // 
            // tbspfPrice
            // 
            this.tbspfPrice.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfPrice.Location = new System.Drawing.Point(311, 184);
            this.tbspfPrice.Name = "tbspfPrice";
            this.tbspfPrice.Size = new System.Drawing.Size(159, 26);
            this.tbspfPrice.TabIndex = 24;
            // 
            // tbspfCategory
            // 
            this.tbspfCategory.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfCategory.Location = new System.Drawing.Point(311, 138);
            this.tbspfCategory.Name = "tbspfCategory";
            this.tbspfCategory.Size = new System.Drawing.Size(159, 26);
            this.tbspfCategory.TabIndex = 23;
            // 
            // tbspfPName
            // 
            this.tbspfPName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfPName.Location = new System.Drawing.Point(311, 92);
            this.tbspfPName.Name = "tbspfPName";
            this.tbspfPName.Size = new System.Drawing.Size(159, 26);
            this.tbspfPName.TabIndex = 22;
            // 
            // tbspfStock
            // 
            this.tbspfStock.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfStock.Location = new System.Drawing.Point(311, 228);
            this.tbspfStock.Name = "tbspfStock";
            this.tbspfStock.Size = new System.Drawing.Size(159, 26);
            this.tbspfStock.TabIndex = 21;
            // 
            // tbspfProductId
            // 
            this.tbspfProductId.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tbspfProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbspfProductId.Location = new System.Drawing.Point(311, 45);
            this.tbspfProductId.Name = "tbspfProductId";
            this.tbspfProductId.Size = new System.Drawing.Size(159, 26);
            this.tbspfProductId.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(219, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "Details :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(158, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Stock Quantity :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(236, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Price :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Category :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(167, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Product Name :";
            // 
            // lbProductId
            // 
            this.lbProductId.AutoSize = true;
            this.lbProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProductId.Location = new System.Drawing.Point(193, 48);
            this.lbProductId.Name = "lbProductId";
            this.lbProductId.Size = new System.Drawing.Size(105, 20);
            this.lbProductId.TabIndex = 14;
            this.lbProductId.Text = "Product ID :";
            // 
            // AddProductshf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(677, 518);
            this.Controls.Add(this.btnspfBack);
            this.Controls.Add(this.btnspfAddProduct);
            this.Controls.Add(this.tbspfDetails);
            this.Controls.Add(this.tbspfPrice);
            this.Controls.Add(this.tbspfCategory);
            this.Controls.Add(this.tbspfPName);
            this.Controls.Add(this.tbspfStock);
            this.Controls.Add(this.tbspfProductId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbProductId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddProductshf";
            this.Text = "AddProductshf";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnspfBack;
        private System.Windows.Forms.Button btnspfAddProduct;
        private System.Windows.Forms.TextBox tbspfDetails;
        private System.Windows.Forms.TextBox tbspfPrice;
        private System.Windows.Forms.TextBox tbspfCategory;
        private System.Windows.Forms.TextBox tbspfPName;
        private System.Windows.Forms.TextBox tbspfStock;
        private System.Windows.Forms.TextBox tbspfProductId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbProductId;
    }
}