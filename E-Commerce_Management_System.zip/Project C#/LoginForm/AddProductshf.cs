﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class AddProductshf : Form
    {
        public AddProductshf()
        {
            InitializeComponent();
        }
        Product p = new Product();

        private void btnspfBack_Click(object sender, EventArgs e)
        {
            SellerHomeForm s = new SellerHomeForm();
            s.Show();
            this.Hide();
        }
        public void clear()
        {
            tbspfProductId.Clear();
            tbspfPName.Clear();
            tbspfCategory.Clear();
            tbspfPrice.Clear();
            tbspfStock.Clear();
            tbspfDetails.Clear();
        }
        private void btnspfAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                p.ProductID = tbspfProductId.Text;
                p.ProductName = tbspfPName.Text;
                p.Category = tbspfCategory.Text;
                p.Price = Convert.ToDouble(tbspfPrice.Text);
                p.StockQuantity = Convert.ToInt32(tbspfStock.Text);
                p.Details = tbspfDetails.Text;

            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = p.AddProduct(p);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }
    }
}
