﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;

namespace LoginForm
{
    class Admin
    {
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string SecurityAns { get; set; }
        public string Password { get; set; }
        public string AdminType { get; set; }
        public string Gender { get; set; }
        public string DoB { get; set; }

        string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\AdminOperation.mdf;Integrated Security=True;Connect Timeout=30";

        public DataTable showAllAdminList()
        {
            SqlConnection sqc = new SqlConnection(connection);
            string q = "Select * From AdminOperation";
            SqlDataAdapter sqd = new SqlDataAdapter(q, sqc);
            DataTable dt = new DataTable();
            sqd.Fill(dt);

            return dt;
        }
        public bool InsertAdmin(Admin a)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Insert into AdminOperation (UserId,Name,Email,PhoneNO,Age,Address,SecurityAns,Password,AdminType,Gender,DoB) Values (@UserId,@Name,@Email,@PhoneNO,@Age,@Address,@SecurityAns,@Password,@AdminType,@Gender,@DoB)";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", a.UserId);
                cmd.Parameters.AddWithValue("@Name", a.Name);
                cmd.Parameters.AddWithValue("@Email", a.Email);
                cmd.Parameters.AddWithValue("@PhoneNO", a.PhoneNo);
                cmd.Parameters.AddWithValue("@Age", a.Age);
                cmd.Parameters.AddWithValue("@Address", a.Address);
                cmd.Parameters.AddWithValue("@SecurityAns", a.SecurityAns);
                cmd.Parameters.AddWithValue("@Password", a.Password);
                cmd.Parameters.AddWithValue("@AdminType", a.AdminType);
                cmd.Parameters.AddWithValue("@Gender", a.Gender);
                cmd.Parameters.AddWithValue("@DoB", a.DoB);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }

            }
           catch (Exception e)
           {
               return false;
           }
           finally
           {
               sqc.Close();
           }
            return success;
        }

        public bool updateAdminOperation(Admin a1)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Update AdminOperation set  Name=@Name, Email=@Email, PhoneNO=@PhoneNO, Age=@Age, Address=@Address, SecurityAns=@SecurityAns, Password=@Password,AdminType=@AdminType, " +
                    "Gender=@Gender, DoB=@DoB Where UserId=@UserId";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", a1.UserId);
                cmd.Parameters.AddWithValue("@Name", a1.Name);
                cmd.Parameters.AddWithValue("@Email", a1.Email);
                cmd.Parameters.AddWithValue("@PhoneNO", a1.PhoneNo);
                cmd.Parameters.AddWithValue("@Age", a1.Age);
                cmd.Parameters.AddWithValue("@Address", a1.Address);
                cmd.Parameters.AddWithValue("@SecurityAns", a1.SecurityAns);
                cmd.Parameters.AddWithValue("@Password", a1.Password);
                cmd.Parameters.AddWithValue("@AdminType", a1.AdminType);
                cmd.Parameters.AddWithValue("@Gender", a1.Gender);
                cmd.Parameters.AddWithValue("@DoB", a1.DoB);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool deleteAdminOperation(Admin s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Delete from AdminOperation Where UserId=@UserId";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", s.UserId);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

    }
}
