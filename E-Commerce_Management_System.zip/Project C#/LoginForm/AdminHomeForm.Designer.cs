﻿
namespace LoginForm
{
    partial class AdminHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminHomeForm));
            this.btnahfAdminOperation = new System.Windows.Forms.Button();
            this.btnahfSellerOperation = new System.Windows.Forms.Button();
            this.btnahfCustomerOperation = new System.Windows.Forms.Button();
            this.btnahfViewAllProducts = new System.Windows.Forms.Button();
            this.btnahfAddProducts = new System.Windows.Forms.Button();
            this.btnahfRemoveProducts = new System.Windows.Forms.Button();
            this.btnahfViewAllOrders = new System.Windows.Forms.Button();
            this.btnahfLogOut = new System.Windows.Forms.Button();
            this.btnahfUpdatePassword = new System.Windows.Forms.Button();
            this.btnahfUpdateProfile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnahfAdminOperation
            // 
            this.btnahfAdminOperation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfAdminOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfAdminOperation.ForeColor = System.Drawing.Color.Black;
            this.btnahfAdminOperation.Location = new System.Drawing.Point(12, 204);
            this.btnahfAdminOperation.Name = "btnahfAdminOperation";
            this.btnahfAdminOperation.Size = new System.Drawing.Size(90, 40);
            this.btnahfAdminOperation.TabIndex = 0;
            this.btnahfAdminOperation.Text = "Admin Opertaion";
            this.btnahfAdminOperation.UseVisualStyleBackColor = false;
            this.btnahfAdminOperation.Click += new System.EventHandler(this.btnahfAdminOperation_Click);
            // 
            // btnahfSellerOperation
            // 
            this.btnahfSellerOperation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfSellerOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfSellerOperation.ForeColor = System.Drawing.Color.Black;
            this.btnahfSellerOperation.Location = new System.Drawing.Point(114, 46);
            this.btnahfSellerOperation.Name = "btnahfSellerOperation";
            this.btnahfSellerOperation.Size = new System.Drawing.Size(90, 40);
            this.btnahfSellerOperation.TabIndex = 1;
            this.btnahfSellerOperation.Text = "Seller Opertaion";
            this.btnahfSellerOperation.UseVisualStyleBackColor = false;
            this.btnahfSellerOperation.Click += new System.EventHandler(this.btnahfSellerOperation_Click);
            // 
            // btnahfCustomerOperation
            // 
            this.btnahfCustomerOperation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfCustomerOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfCustomerOperation.ForeColor = System.Drawing.Color.Black;
            this.btnahfCustomerOperation.Location = new System.Drawing.Point(185, 204);
            this.btnahfCustomerOperation.Name = "btnahfCustomerOperation";
            this.btnahfCustomerOperation.Size = new System.Drawing.Size(90, 40);
            this.btnahfCustomerOperation.TabIndex = 2;
            this.btnahfCustomerOperation.Text = "Customer Opertaion";
            this.btnahfCustomerOperation.UseVisualStyleBackColor = false;
            this.btnahfCustomerOperation.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnahfViewAllProducts
            // 
            this.btnahfViewAllProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfViewAllProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfViewAllProducts.ForeColor = System.Drawing.Color.Black;
            this.btnahfViewAllProducts.Location = new System.Drawing.Point(648, 287);
            this.btnahfViewAllProducts.Name = "btnahfViewAllProducts";
            this.btnahfViewAllProducts.Size = new System.Drawing.Size(90, 40);
            this.btnahfViewAllProducts.TabIndex = 3;
            this.btnahfViewAllProducts.Text = "View All Products";
            this.btnahfViewAllProducts.UseVisualStyleBackColor = false;
            this.btnahfViewAllProducts.Click += new System.EventHandler(this.btnahfViewAllProducts_Click);
            // 
            // btnahfAddProducts
            // 
            this.btnahfAddProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfAddProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfAddProducts.ForeColor = System.Drawing.Color.Black;
            this.btnahfAddProducts.Location = new System.Drawing.Point(648, 190);
            this.btnahfAddProducts.Name = "btnahfAddProducts";
            this.btnahfAddProducts.Size = new System.Drawing.Size(90, 40);
            this.btnahfAddProducts.TabIndex = 4;
            this.btnahfAddProducts.Text = "Add Products";
            this.btnahfAddProducts.UseVisualStyleBackColor = false;
            this.btnahfAddProducts.Click += new System.EventHandler(this.btnahfAddProducts_Click);
            // 
            // btnahfRemoveProducts
            // 
            this.btnahfRemoveProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfRemoveProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfRemoveProducts.ForeColor = System.Drawing.Color.Black;
            this.btnahfRemoveProducts.Location = new System.Drawing.Point(484, 401);
            this.btnahfRemoveProducts.Name = "btnahfRemoveProducts";
            this.btnahfRemoveProducts.Size = new System.Drawing.Size(90, 40);
            this.btnahfRemoveProducts.TabIndex = 5;
            this.btnahfRemoveProducts.Text = "Remove Products";
            this.btnahfRemoveProducts.UseVisualStyleBackColor = false;
            this.btnahfRemoveProducts.Click += new System.EventHandler(this.btnahfRemoveProducts_Click);
            // 
            // btnahfViewAllOrders
            // 
            this.btnahfViewAllOrders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfViewAllOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfViewAllOrders.ForeColor = System.Drawing.Color.Black;
            this.btnahfViewAllOrders.Location = new System.Drawing.Point(114, 316);
            this.btnahfViewAllOrders.Name = "btnahfViewAllOrders";
            this.btnahfViewAllOrders.Size = new System.Drawing.Size(90, 40);
            this.btnahfViewAllOrders.TabIndex = 6;
            this.btnahfViewAllOrders.Text = "View All Orders";
            this.btnahfViewAllOrders.UseVisualStyleBackColor = false;
            this.btnahfViewAllOrders.Click += new System.EventHandler(this.btnahfViewAllOrders_Click);
            // 
            // btnahfLogOut
            // 
            this.btnahfLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfLogOut.ForeColor = System.Drawing.Color.Black;
            this.btnahfLogOut.Location = new System.Drawing.Point(262, 416);
            this.btnahfLogOut.Name = "btnahfLogOut";
            this.btnahfLogOut.Size = new System.Drawing.Size(62, 40);
            this.btnahfLogOut.TabIndex = 7;
            this.btnahfLogOut.Text = "Log Out";
            this.btnahfLogOut.UseVisualStyleBackColor = false;
            this.btnahfLogOut.Click += new System.EventHandler(this.btnahfLogOut_Click);
            // 
            // btnahfUpdatePassword
            // 
            this.btnahfUpdatePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfUpdatePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfUpdatePassword.ForeColor = System.Drawing.Color.Black;
            this.btnahfUpdatePassword.Location = new System.Drawing.Point(729, 443);
            this.btnahfUpdatePassword.Name = "btnahfUpdatePassword";
            this.btnahfUpdatePassword.Size = new System.Drawing.Size(90, 40);
            this.btnahfUpdatePassword.TabIndex = 8;
            this.btnahfUpdatePassword.Text = "Update Password";
            this.btnahfUpdatePassword.UseVisualStyleBackColor = false;
            this.btnahfUpdatePassword.Click += new System.EventHandler(this.btnahfUpdatePassword_Click);
            // 
            // btnahfUpdateProfile
            // 
            this.btnahfUpdateProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfUpdateProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfUpdateProfile.ForeColor = System.Drawing.Color.Black;
            this.btnahfUpdateProfile.Location = new System.Drawing.Point(729, 46);
            this.btnahfUpdateProfile.Name = "btnahfUpdateProfile";
            this.btnahfUpdateProfile.Size = new System.Drawing.Size(90, 40);
            this.btnahfUpdateProfile.TabIndex = 9;
            this.btnahfUpdateProfile.Text = "Update Profile";
            this.btnahfUpdateProfile.UseVisualStyleBackColor = false;
            this.btnahfUpdateProfile.Click += new System.EventHandler(this.btnahfUpdateProfile_Click);
            // 
            // AdminHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(852, 523);
            this.Controls.Add(this.btnahfUpdateProfile);
            this.Controls.Add(this.btnahfUpdatePassword);
            this.Controls.Add(this.btnahfLogOut);
            this.Controls.Add(this.btnahfViewAllOrders);
            this.Controls.Add(this.btnahfRemoveProducts);
            this.Controls.Add(this.btnahfAddProducts);
            this.Controls.Add(this.btnahfViewAllProducts);
            this.Controls.Add(this.btnahfCustomerOperation);
            this.Controls.Add(this.btnahfSellerOperation);
            this.Controls.Add(this.btnahfAdminOperation);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "AdminHomeForm";
            this.Text = "AdminHomeForm";
            this.Load += new System.EventHandler(this.AdminHomeForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnahfAdminOperation;
        private System.Windows.Forms.Button btnahfSellerOperation;
        private System.Windows.Forms.Button btnahfCustomerOperation;
        private System.Windows.Forms.Button btnahfViewAllProducts;
        private System.Windows.Forms.Button btnahfAddProducts;
        private System.Windows.Forms.Button btnahfRemoveProducts;
        private System.Windows.Forms.Button btnahfViewAllOrders;
        private System.Windows.Forms.Button btnahfLogOut;
        private System.Windows.Forms.Button btnahfUpdatePassword;
        private System.Windows.Forms.Button btnahfUpdateProfile;
    }
}