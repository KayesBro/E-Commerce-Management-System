﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class AdminHomeForm : Form
    {
        public AdminHomeForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerOperationForm cof = new CustomerOperationForm();
            cof.Show();
            this.Hide();
        }

        private void AdminHomeForm_Load(object sender, EventArgs e)
        {

        }

        private void btnahfAddProducts_Click(object sender, EventArgs e)
        {
            AddProductForm apf = new AddProductForm();
            apf.Show();
            this.Hide();
        }

        private void btnahfUpdateProfile_Click(object sender, EventArgs e)
        {
            AdminOperationForm aof = new AdminOperationForm();
            aof.Show();
            this.Hide();
        }

        private void btnahfAdminOperation_Click(object sender, EventArgs e)
        {
            AdminOperationForm aof = new AdminOperationForm();
            aof.Show();
            this.Hide();
        }

        private void btnahfSellerOperation_Click(object sender, EventArgs e)
        {
            SellerOperationForm sof = new SellerOperationForm();
            sof.Show();
            this.Hide();
        }

        private void btnahfLogOut_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void btnahfViewAllProducts_Click(object sender, EventArgs e)
        {
            AdminViewAllProductForm vapf = new AdminViewAllProductForm();
            vapf.Show();
            this.Hide();
        }

        private void btnahfUpdatePassword_Click(object sender, EventArgs e)
        {
            AdminOperationForm aaa = new AdminOperationForm();
            aaa.Show();
            this.Hide();
        }

        private void btnahfRemoveProducts_Click(object sender, EventArgs e)
        {
            AdminRemoveProductForm arpf = new AdminRemoveProductForm();
            arpf.Show();
            this.Hide();
        }

        private void btnahfViewAllOrders_Click(object sender, EventArgs e)
        {
            ViewOrderListahf v = new ViewOrderListahf();
            v.Show();
            this.Hide();
        }
    }
}
