﻿
namespace LoginForm
{
    partial class AdminOperationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminOperationForm));
            this.gbaofGender = new System.Windows.Forms.GroupBox();
            this.rbaofgMale = new System.Windows.Forms.RadioButton();
            this.rbaofgFemale = new System.Windows.Forms.RadioButton();
            this.tbaofAdminType = new System.Windows.Forms.TextBox();
            this.tbaofPassword = new System.Windows.Forms.TextBox();
            this.tbaofSecurityAns = new System.Windows.Forms.TextBox();
            this.tbaofAddress = new System.Windows.Forms.TextBox();
            this.tbaofAge = new System.Windows.Forms.TextBox();
            this.tbaofPhoneNo = new System.Windows.Forms.TextBox();
            this.tbaofEmail = new System.Windows.Forms.TextBox();
            this.tbaofName = new System.Windows.Forms.TextBox();
            this.tbaofUserId = new System.Windows.Forms.TextBox();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.lrPassword = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btnaofBack = new System.Windows.Forms.Button();
            this.dgvAdminOperation = new System.Windows.Forms.DataGridView();
            this.btnaofAdd = new System.Windows.Forms.Button();
            this.btnaofShow = new System.Windows.Forms.Button();
            this.btnaofUpdate = new System.Windows.Forms.Button();
            this.btnaofDelete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpaofDoB = new System.Windows.Forms.DateTimePicker();
            this.gbaofGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminOperation)).BeginInit();
            this.SuspendLayout();
            // 
            // gbaofGender
            // 
            this.gbaofGender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbaofGender.Controls.Add(this.rbaofgMale);
            this.gbaofGender.Controls.Add(this.rbaofgFemale);
            this.gbaofGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbaofGender.Location = new System.Drawing.Point(493, 194);
            this.gbaofGender.Name = "gbaofGender";
            this.gbaofGender.Size = new System.Drawing.Size(284, 28);
            this.gbaofGender.TabIndex = 44;
            this.gbaofGender.TabStop = false;
            this.gbaofGender.Text = "Gender : ";
            this.gbaofGender.Enter += new System.EventHandler(this.gbaofGender_Enter);
            // 
            // rbaofgMale
            // 
            this.rbaofgMale.AutoSize = true;
            this.rbaofgMale.BackColor = System.Drawing.Color.LightPink;
            this.rbaofgMale.Location = new System.Drawing.Point(83, 1);
            this.rbaofgMale.Name = "rbaofgMale";
            this.rbaofgMale.Size = new System.Drawing.Size(63, 24);
            this.rbaofgMale.TabIndex = 20;
            this.rbaofgMale.TabStop = true;
            this.rbaofgMale.Text = "Male";
            this.rbaofgMale.UseVisualStyleBackColor = false;
            this.rbaofgMale.CheckedChanged += new System.EventHandler(this.rbaofgMale_CheckedChanged);
            // 
            // rbaofgFemale
            // 
            this.rbaofgFemale.AutoSize = true;
            this.rbaofgFemale.BackColor = System.Drawing.Color.LightPink;
            this.rbaofgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbaofgFemale.Name = "rbaofgFemale";
            this.rbaofgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbaofgFemale.TabIndex = 21;
            this.rbaofgFemale.TabStop = true;
            this.rbaofgFemale.Text = "Female";
            this.rbaofgFemale.UseVisualStyleBackColor = false;
            this.rbaofgFemale.CheckedChanged += new System.EventHandler(this.rbaofgFemale_CheckedChanged);
            // 
            // tbaofAdminType
            // 
            this.tbaofAdminType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofAdminType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofAdminType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofAdminType.Location = new System.Drawing.Point(597, 154);
            this.tbaofAdminType.Name = "tbaofAdminType";
            this.tbaofAdminType.Size = new System.Drawing.Size(139, 26);
            this.tbaofAdminType.TabIndex = 43;
            // 
            // tbaofPassword
            // 
            this.tbaofPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofPassword.Location = new System.Drawing.Point(597, 116);
            this.tbaofPassword.Name = "tbaofPassword";
            this.tbaofPassword.PasswordChar = '*';
            this.tbaofPassword.Size = new System.Drawing.Size(139, 26);
            this.tbaofPassword.TabIndex = 42;
            this.tbaofPassword.UseSystemPasswordChar = true;
            // 
            // tbaofSecurityAns
            // 
            this.tbaofSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofSecurityAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofSecurityAns.Location = new System.Drawing.Point(597, 77);
            this.tbaofSecurityAns.Name = "tbaofSecurityAns";
            this.tbaofSecurityAns.Size = new System.Drawing.Size(139, 26);
            this.tbaofSecurityAns.TabIndex = 41;
            // 
            // tbaofAddress
            // 
            this.tbaofAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofAddress.Location = new System.Drawing.Point(581, 16);
            this.tbaofAddress.Name = "tbaofAddress";
            this.tbaofAddress.Size = new System.Drawing.Size(139, 26);
            this.tbaofAddress.TabIndex = 40;
            // 
            // tbaofAge
            // 
            this.tbaofAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofAge.Location = new System.Drawing.Point(248, 172);
            this.tbaofAge.Name = "tbaofAge";
            this.tbaofAge.Size = new System.Drawing.Size(139, 26);
            this.tbaofAge.TabIndex = 39;
            // 
            // tbaofPhoneNo
            // 
            this.tbaofPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofPhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofPhoneNo.Location = new System.Drawing.Point(248, 135);
            this.tbaofPhoneNo.Name = "tbaofPhoneNo";
            this.tbaofPhoneNo.Size = new System.Drawing.Size(139, 26);
            this.tbaofPhoneNo.TabIndex = 38;
            // 
            // tbaofEmail
            // 
            this.tbaofEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofEmail.Location = new System.Drawing.Point(248, 93);
            this.tbaofEmail.Name = "tbaofEmail";
            this.tbaofEmail.Size = new System.Drawing.Size(139, 26);
            this.tbaofEmail.TabIndex = 37;
            // 
            // tbaofName
            // 
            this.tbaofName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofName.Location = new System.Drawing.Point(248, 57);
            this.tbaofName.Name = "tbaofName";
            this.tbaofName.Size = new System.Drawing.Size(139, 26);
            this.tbaofName.TabIndex = 36;
            // 
            // tbaofUserId
            // 
            this.tbaofUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbaofUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbaofUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbaofUserId.Location = new System.Drawing.Point(248, 15);
            this.tbaofUserId.Name = "tbaofUserId";
            this.tbaofUserId.Size = new System.Drawing.Size(139, 26);
            this.tbaofUserId.TabIndex = 35;
            this.tbaofUserId.TextChanged += new System.EventHandler(this.tbaofUserId_TextChanged);
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(489, 155);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(109, 20);
            this.lrAdminType.TabIndex = 34;
            this.lrAdminType.Text = "Admin Type : ";
            // 
            // lrPassword
            // 
            this.lrPassword.AutoSize = true;
            this.lrPassword.BackColor = System.Drawing.Color.Transparent;
            this.lrPassword.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPassword.Location = new System.Drawing.Point(505, 117);
            this.lrPassword.Name = "lrPassword";
            this.lrPassword.Size = new System.Drawing.Size(90, 20);
            this.lrPassword.TabIndex = 33;
            this.lrPassword.Text = "Password : ";
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(457, 79);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 32;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(457, 50);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 31;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(501, 19);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 30;
            this.lrAddress.Text = "Address : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(198, 174);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 29;
            this.lrAge.Text = "Age : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(156, 137);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 28;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(190, 97);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 27;
            this.lrEmail.Text = "Email : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(185, 59);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 26;
            this.lrName.Text = "Name : ";
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(177, 18);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 25;
            this.lrUserId.Text = "User Id : ";
            // 
            // btnaofBack
            // 
            this.btnaofBack.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnaofBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaofBack.Location = new System.Drawing.Point(758, 262);
            this.btnaofBack.Name = "btnaofBack";
            this.btnaofBack.Size = new System.Drawing.Size(75, 31);
            this.btnaofBack.TabIndex = 45;
            this.btnaofBack.Text = "Back";
            this.btnaofBack.UseVisualStyleBackColor = false;
            this.btnaofBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvAdminOperation
            // 
            this.dgvAdminOperation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvAdminOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdminOperation.Location = new System.Drawing.Point(81, 299);
            this.dgvAdminOperation.Name = "dgvAdminOperation";
            this.dgvAdminOperation.Size = new System.Drawing.Size(752, 187);
            this.dgvAdminOperation.TabIndex = 46;
            this.dgvAdminOperation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dgvAdminOperation.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvAdminOperation_RowHeaderMouseClick);
            // 
            // btnaofAdd
            // 
            this.btnaofAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnaofAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaofAdd.Location = new System.Drawing.Point(95, 262);
            this.btnaofAdd.Name = "btnaofAdd";
            this.btnaofAdd.Size = new System.Drawing.Size(75, 31);
            this.btnaofAdd.TabIndex = 47;
            this.btnaofAdd.Text = "Add";
            this.btnaofAdd.UseVisualStyleBackColor = false;
            this.btnaofAdd.Click += new System.EventHandler(this.btnaofAdd_Click);
            // 
            // btnaofShow
            // 
            this.btnaofShow.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnaofShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaofShow.Location = new System.Drawing.Point(188, 262);
            this.btnaofShow.Name = "btnaofShow";
            this.btnaofShow.Size = new System.Drawing.Size(75, 31);
            this.btnaofShow.TabIndex = 48;
            this.btnaofShow.Text = "Show";
            this.btnaofShow.UseVisualStyleBackColor = false;
            this.btnaofShow.Click += new System.EventHandler(this.btnaofShow_Click);
            // 
            // btnaofUpdate
            // 
            this.btnaofUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnaofUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaofUpdate.Location = new System.Drawing.Point(279, 262);
            this.btnaofUpdate.Name = "btnaofUpdate";
            this.btnaofUpdate.Size = new System.Drawing.Size(75, 31);
            this.btnaofUpdate.TabIndex = 49;
            this.btnaofUpdate.Text = "Update";
            this.btnaofUpdate.UseVisualStyleBackColor = false;
            this.btnaofUpdate.Click += new System.EventHandler(this.btnaofUpdate_Click);
            // 
            // btnaofDelete
            // 
            this.btnaofDelete.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnaofDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaofDelete.Location = new System.Drawing.Point(374, 262);
            this.btnaofDelete.Name = "btnaofDelete";
            this.btnaofDelete.Size = new System.Drawing.Size(75, 31);
            this.btnaofDelete.TabIndex = 50;
            this.btnaofDelete.Text = "Delete";
            this.btnaofDelete.UseVisualStyleBackColor = false;
            this.btnaofDelete.Click += new System.EventHandler(this.btnaofDelete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(478, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 51;
            this.label1.Text = "Search : ";
            // 
            // searchBox
            // 
            this.searchBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.searchBox.Location = new System.Drawing.Point(551, 264);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(177, 26);
            this.searchBox.TabIndex = 52;
            this.searchBox.TextChanged += new System.EventHandler(this.searchBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(135, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 53;
            this.label2.Text = "Date Of Birth : ";
            // 
            // dtpaofDoB
            // 
            this.dtpaofDoB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpaofDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpaofDoB.Location = new System.Drawing.Point(248, 216);
            this.dtpaofDoB.Name = "dtpaofDoB";
            this.dtpaofDoB.Size = new System.Drawing.Size(239, 22);
            this.dtpaofDoB.TabIndex = 54;
            // 
            // AdminOperationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(910, 513);
            this.Controls.Add(this.dtpaofDoB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnaofDelete);
            this.Controls.Add(this.btnaofUpdate);
            this.Controls.Add(this.btnaofShow);
            this.Controls.Add(this.btnaofAdd);
            this.Controls.Add(this.dgvAdminOperation);
            this.Controls.Add(this.btnaofBack);
            this.Controls.Add(this.gbaofGender);
            this.Controls.Add(this.tbaofAdminType);
            this.Controls.Add(this.tbaofPassword);
            this.Controls.Add(this.tbaofSecurityAns);
            this.Controls.Add(this.tbaofAddress);
            this.Controls.Add(this.tbaofAge);
            this.Controls.Add(this.tbaofPhoneNo);
            this.Controls.Add(this.tbaofEmail);
            this.Controls.Add(this.tbaofName);
            this.Controls.Add(this.tbaofUserId);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.lrPassword);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminOperationForm";
            this.Text = "AdminOperationForm";
            this.gbaofGender.ResumeLayout(false);
            this.gbaofGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminOperation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbaofGender;
        private System.Windows.Forms.RadioButton rbaofgMale;
        private System.Windows.Forms.RadioButton rbaofgFemale;
        private System.Windows.Forms.TextBox tbaofAdminType;
        private System.Windows.Forms.TextBox tbaofPassword;
        private System.Windows.Forms.TextBox tbaofSecurityAns;
        private System.Windows.Forms.TextBox tbaofAddress;
        private System.Windows.Forms.TextBox tbaofAge;
        private System.Windows.Forms.TextBox tbaofPhoneNo;
        private System.Windows.Forms.TextBox tbaofEmail;
        private System.Windows.Forms.TextBox tbaofName;
        private System.Windows.Forms.TextBox tbaofUserId;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.Label lrPassword;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btnaofBack;
        private System.Windows.Forms.DataGridView dgvAdminOperation;
        private System.Windows.Forms.Button btnaofAdd;
        private System.Windows.Forms.Button btnaofShow;
        private System.Windows.Forms.Button btnaofUpdate;
        private System.Windows.Forms.Button btnaofDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpaofDoB;
    }
}