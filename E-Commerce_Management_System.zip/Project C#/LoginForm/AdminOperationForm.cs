﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class AdminOperationForm : Form
    {
        public AdminOperationForm()
        {
            InitializeComponent();
        }

        Admin ad = new Admin();
        private void button1_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbaofUserId_TextChanged(object sender, EventArgs e)
        {

        }

        public void clear()
        {
            tbaofUserId.Clear();
            tbaofName.Clear();
            tbaofEmail.Clear();
            tbaofPhoneNo.Clear();
            tbaofAge.Clear();
            tbaofAddress.Clear();
            tbaofSecurityAns.Clear();
            tbaofPassword.Clear();
            tbaofAdminType.Clear();
        }
        private void btnaofAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ad.UserId = tbaofUserId.Text;
                ad.Name = tbaofName.Text;
                ad.Email = tbaofEmail.Text;
                ad.PhoneNo = tbaofPhoneNo.Text;
                ad.Age = Convert.ToInt32(tbaofAge.Text);
                ad.Address = tbaofAddress.Text;
                ad.SecurityAns = tbaofSecurityAns.Text;
                ad.Password = tbaofPassword.Text;
                ad.AdminType = tbaofAdminType.Text;
                ad.DoB = dtpaofDoB.Value.ToString();
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = ad.InsertAdmin(ad);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btnaofShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ad.showAllAdminList();
            dgvAdminOperation.DataSource = dt;
        }

        private void gbaofGender_Enter(object sender, EventArgs e)
        {

        }

        private void rbaofgMale_CheckedChanged(object sender, EventArgs e)
        {
            ad.Gender = "Male";
        }

        private void rbaofgFemale_CheckedChanged(object sender, EventArgs e)
        {
            ad.Gender = "Female";
        }

        private void btnaofUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ad.UserId = tbaofUserId.Text;
                ad.Name = tbaofName.Text;
                ad.Email = tbaofEmail.Text;
                ad.PhoneNo = tbaofPhoneNo.Text;
                ad.Age = Convert.ToInt32(tbaofAge.Text);
                ad.Address = tbaofAddress.Text;
                ad.SecurityAns = tbaofSecurityAns.Text;
                ad.Password = tbaofPassword.Text;
                ad.AdminType = tbaofAdminType.Text;
                ad.DoB = dtpaofDoB.Value.ToString();

                bool success = ad.updateAdminOperation(ad);
                if (success == true)
                {
                    MessageBox.Show("Successfully Updated!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = ad.showAllAdminList();
            dgvAdminOperation.DataSource = dt;
        }

        private void dgvAdminOperation_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int row_index = e.RowIndex;
            tbaofUserId.Text = dgvAdminOperation.Rows[row_index].Cells[0].Value.ToString();
            tbaofName.Text = dgvAdminOperation.Rows[row_index].Cells[1].Value.ToString();
            tbaofEmail.Text = dgvAdminOperation.Rows[row_index].Cells[2].Value.ToString();
            tbaofPhoneNo.Text = dgvAdminOperation.Rows[row_index].Cells[3].Value.ToString();
            tbaofAge.Text = dgvAdminOperation.Rows[row_index].Cells[4].Value.ToString();
            tbaofAddress.Text = dgvAdminOperation.Rows[row_index].Cells[5].Value.ToString();
            tbaofSecurityAns.Text = dgvAdminOperation.Rows[row_index].Cells[6].Value.ToString();
            tbaofPassword.Text = dgvAdminOperation.Rows[row_index].Cells[7].Value.ToString();
            tbaofAdminType.Text = dgvAdminOperation.Rows[row_index].Cells[8].Value.ToString();
            gbaofGender.Text = dgvAdminOperation.Rows[row_index].Cells[9].Value.ToString();
            dtpaofDoB.Text = dgvAdminOperation.Rows[row_index].Cells[10].Value.ToString();
        }

        private void btnaofDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ad.UserId = tbaofUserId.Text;

                bool success = ad.deleteAdminOperation(ad);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = ad.showAllAdminList();
            dgvAdminOperation.DataSource = dt;
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\AdminOperation.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(connection);
            string q = "Select * From AdminOperation Where Name Like '%" + searchBox.Text + "%'";
            SqlDataAdapter sda = new SqlDataAdapter(q, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvAdminOperation.DataSource = dt;
        }
    }
}
