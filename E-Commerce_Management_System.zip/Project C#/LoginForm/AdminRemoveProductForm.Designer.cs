﻿
namespace LoginForm
{
    partial class AdminRemoveProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminRemoveProductForm));
            this.btnarpfShow = new System.Windows.Forms.Button();
            this.btnarapfBack = new System.Windows.Forms.Button();
            this.dgvAdminRemoveProduct = new System.Windows.Forms.DataGridView();
            this.tbarpfProductId = new System.Windows.Forms.TextBox();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btnarpfDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminRemoveProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // btnarpfShow
            // 
            this.btnarpfShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnarpfShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarpfShow.ForeColor = System.Drawing.Color.Black;
            this.btnarpfShow.Location = new System.Drawing.Point(484, 9);
            this.btnarpfShow.Name = "btnarpfShow";
            this.btnarpfShow.Size = new System.Drawing.Size(90, 40);
            this.btnarpfShow.TabIndex = 7;
            this.btnarpfShow.Text = "Show";
            this.btnarpfShow.UseVisualStyleBackColor = false;
            this.btnarpfShow.Click += new System.EventHandler(this.btnarpfShow_Click);
            // 
            // btnarapfBack
            // 
            this.btnarapfBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnarapfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarapfBack.ForeColor = System.Drawing.Color.Black;
            this.btnarapfBack.Location = new System.Drawing.Point(614, 9);
            this.btnarapfBack.Name = "btnarapfBack";
            this.btnarapfBack.Size = new System.Drawing.Size(90, 40);
            this.btnarapfBack.TabIndex = 6;
            this.btnarapfBack.Text = "Back";
            this.btnarapfBack.UseVisualStyleBackColor = false;
            this.btnarapfBack.Click += new System.EventHandler(this.btnarapfBack_Click);
            // 
            // dgvAdminRemoveProduct
            // 
            this.dgvAdminRemoveProduct.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvAdminRemoveProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdminRemoveProduct.Location = new System.Drawing.Point(12, 55);
            this.dgvAdminRemoveProduct.Name = "dgvAdminRemoveProduct";
            this.dgvAdminRemoveProduct.Size = new System.Drawing.Size(704, 419);
            this.dgvAdminRemoveProduct.TabIndex = 5;
            this.dgvAdminRemoveProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAdminRemoveProduct_CellContentClick);
            // 
            // tbarpfProductId
            // 
            this.tbarpfProductId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbarpfProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbarpfProductId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbarpfProductId.Location = new System.Drawing.Point(149, 13);
            this.tbarpfProductId.Name = "tbarpfProductId";
            this.tbarpfProductId.Size = new System.Drawing.Size(139, 26);
            this.tbarpfProductId.TabIndex = 36;
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(12, 18);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(140, 20);
            this.lrUserId.TabIndex = 37;
            this.lrUserId.Text = "Enter Product ID : ";
            // 
            // btnarpfDelete
            // 
            this.btnarpfDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnarpfDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarpfDelete.ForeColor = System.Drawing.Color.Black;
            this.btnarpfDelete.Location = new System.Drawing.Point(305, 9);
            this.btnarpfDelete.Name = "btnarpfDelete";
            this.btnarpfDelete.Size = new System.Drawing.Size(90, 40);
            this.btnarpfDelete.TabIndex = 38;
            this.btnarpfDelete.Text = "Delete";
            this.btnarpfDelete.UseVisualStyleBackColor = false;
            this.btnarpfDelete.Click += new System.EventHandler(this.btnarpfDelete_Click);
            // 
            // AdminRemoveProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 489);
            this.Controls.Add(this.btnarpfDelete);
            this.Controls.Add(this.lrUserId);
            this.Controls.Add(this.tbarpfProductId);
            this.Controls.Add(this.btnarpfShow);
            this.Controls.Add(this.btnarapfBack);
            this.Controls.Add(this.dgvAdminRemoveProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminRemoveProductForm";
            this.Text = "AdminRemoveProduct";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminRemoveProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnarpfShow;
        private System.Windows.Forms.Button btnarapfBack;
        private System.Windows.Forms.DataGridView dgvAdminRemoveProduct;
        private System.Windows.Forms.TextBox tbarpfProductId;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btnarpfDelete;
    }
}