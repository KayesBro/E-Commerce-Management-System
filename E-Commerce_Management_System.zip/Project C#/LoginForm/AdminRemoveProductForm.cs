﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class AdminRemoveProductForm : Form
    {
        public AdminRemoveProductForm()
        {
            InitializeComponent();
        }
        Product ad = new Product();

        public void clear()
        {
            tbarpfProductId.Clear();
            
        }
        private void btnarpfDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ad.ProductID = tbarpfProductId.Text;

                bool success = ad.deleteProductOperation(ad);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = ad.showAllProduct();
            dgvAdminRemoveProduct.DataSource = dt;
        }

        private void btnarpfShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ad.showAllProduct();
            dgvAdminRemoveProduct.DataSource = dt;
        }

        private void btnarapfBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        private void dgvAdminRemoveProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
