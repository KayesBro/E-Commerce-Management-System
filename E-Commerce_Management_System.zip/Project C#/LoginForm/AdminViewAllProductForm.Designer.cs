﻿
namespace LoginForm
{
    partial class AdminViewAllProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminViewAllProductForm));
            this.dgvAdminViewAllProduct = new System.Windows.Forms.DataGridView();
            this.btnavapfBack = new System.Windows.Forms.Button();
            this.btnvapfShow = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminViewAllProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvAdminViewAllProduct
            // 
            this.dgvAdminViewAllProduct.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvAdminViewAllProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdminViewAllProduct.Location = new System.Drawing.Point(2, 61);
            this.dgvAdminViewAllProduct.Name = "dgvAdminViewAllProduct";
            this.dgvAdminViewAllProduct.Size = new System.Drawing.Size(855, 419);
            this.dgvAdminViewAllProduct.TabIndex = 0;
            // 
            // btnavapfBack
            // 
            this.btnavapfBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnavapfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnavapfBack.ForeColor = System.Drawing.Color.Black;
            this.btnavapfBack.Location = new System.Drawing.Point(746, 12);
            this.btnavapfBack.Name = "btnavapfBack";
            this.btnavapfBack.Size = new System.Drawing.Size(90, 40);
            this.btnavapfBack.TabIndex = 3;
            this.btnavapfBack.Text = "Back";
            this.btnavapfBack.UseVisualStyleBackColor = false;
            this.btnavapfBack.Click += new System.EventHandler(this.btnvapfBack_Click);
            // 
            // btnvapfShow
            // 
            this.btnvapfShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnvapfShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvapfShow.ForeColor = System.Drawing.Color.Black;
            this.btnvapfShow.Location = new System.Drawing.Point(616, 12);
            this.btnvapfShow.Name = "btnvapfShow";
            this.btnvapfShow.Size = new System.Drawing.Size(90, 40);
            this.btnvapfShow.TabIndex = 4;
            this.btnvapfShow.Text = "Show";
            this.btnvapfShow.UseVisualStyleBackColor = false;
            this.btnvapfShow.Click += new System.EventHandler(this.btnvapfShow_Click);
            // 
            // AdminViewAllProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(859, 480);
            this.Controls.Add(this.btnvapfShow);
            this.Controls.Add(this.btnavapfBack);
            this.Controls.Add(this.dgvAdminViewAllProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminViewAllProductForm";
            this.Text = "AdminViewAllProductForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminViewAllProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAdminViewAllProduct;
        private System.Windows.Forms.Button btnavapfBack;
        private System.Windows.Forms.Button btnvapfShow;
    }
}