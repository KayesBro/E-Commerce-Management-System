﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace LoginForm
{
    public partial class AdminViewAllProductForm : Form
    {
        public AdminViewAllProductForm()
        {
            InitializeComponent();
        }

        Product pp = new Product();

        private void btnvapfBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        private void btnvapfShow_Click(object sender, EventArgs e)
        {
            DataTable dt = pp.showAllProduct();
            dgvAdminViewAllProduct.DataSource = dt;
        }
    }
}
