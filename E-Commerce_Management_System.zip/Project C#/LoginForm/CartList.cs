﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace LoginForm
{
    class CartList
    {
        public string ProductId { get; set; }

        string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\CartList.mdf;Integrated Security=True;Connect Timeout=30";

        public DataTable showAllCartList()
        {
            SqlConnection sqc = new SqlConnection(connection);
            string q = "Select * From CartList";
            SqlDataAdapter sqd = new SqlDataAdapter(q, sqc);
            DataTable dt = new DataTable();
            sqd.Fill(dt);

            return dt;
        }

        public bool AddCart(CartList a)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Insert into CartList (ProductId) Values (@ProductId)";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@ProductId", a.ProductId);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }

            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool deleteCart(CartList s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Delete from CartList Where ProductId=@ProductId";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@ProductId", s.ProductId);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }



    }
}
