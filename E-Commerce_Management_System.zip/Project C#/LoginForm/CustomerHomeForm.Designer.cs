﻿
namespace LoginForm
{
    partial class CustomerHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerHomeForm));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.lrUserId = new System.Windows.Forms.Label();
            this.tbchfSearch = new System.Windows.Forms.TextBox();
            this.btnchfOrderProduct = new System.Windows.Forms.Button();
            this.btnchfCartProduct = new System.Windows.Forms.Button();
            this.dgvchf = new System.Windows.Forms.DataGridView();
            this.btnchfViewProduct = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbchfProductId = new System.Windows.Forms.TextBox();
            this.btnchfOrderNow = new System.Windows.Forms.Button();
            this.btnchfAddCart = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbchfaddCart = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbchfUserId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbchfPayment = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvchf)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Uighur", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(340, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 43);
            this.label1.TabIndex = 5;
            this.label1.Text = "E-Commerce Management System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Script MT Bold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(457, -1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 42);
            this.label2.TabIndex = 6;
            this.label2.Text = "Welcome";
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.ForeColor = System.Drawing.Color.Black;
            this.btnLogOut.Location = new System.Drawing.Point(605, 165);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(70, 36);
            this.btnLogOut.TabIndex = 11;
            this.btnLogOut.Text = "Logout";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(684, 166);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(179, 20);
            this.lrUserId.TabIndex = 39;
            this.lrUserId.Text = "Search Product Name : ";
            this.lrUserId.Click += new System.EventHandler(this.lrUserId_Click);
            // 
            // tbchfSearch
            // 
            this.tbchfSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfSearch.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfSearch.Location = new System.Drawing.Point(864, 163);
            this.tbchfSearch.Name = "tbchfSearch";
            this.tbchfSearch.Size = new System.Drawing.Size(145, 26);
            this.tbchfSearch.TabIndex = 38;
            this.tbchfSearch.TextChanged += new System.EventHandler(this.tbchfSearch_TextChanged_1);
            // 
            // btnchfOrderProduct
            // 
            this.btnchfOrderProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfOrderProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfOrderProduct.ForeColor = System.Drawing.Color.Black;
            this.btnchfOrderProduct.Location = new System.Drawing.Point(453, 165);
            this.btnchfOrderProduct.Name = "btnchfOrderProduct";
            this.btnchfOrderProduct.Size = new System.Drawing.Size(70, 35);
            this.btnchfOrderProduct.TabIndex = 41;
            this.btnchfOrderProduct.Text = "Order Products";
            this.btnchfOrderProduct.UseVisualStyleBackColor = false;
            this.btnchfOrderProduct.Click += new System.EventHandler(this.btnchfUpdateProfile_Click);
            // 
            // btnchfCartProduct
            // 
            this.btnchfCartProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfCartProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfCartProduct.ForeColor = System.Drawing.Color.Black;
            this.btnchfCartProduct.Location = new System.Drawing.Point(529, 166);
            this.btnchfCartProduct.Name = "btnchfCartProduct";
            this.btnchfCartProduct.Size = new System.Drawing.Size(70, 35);
            this.btnchfCartProduct.TabIndex = 42;
            this.btnchfCartProduct.Text = "Cart Products";
            this.btnchfCartProduct.UseVisualStyleBackColor = false;
            this.btnchfCartProduct.Click += new System.EventHandler(this.btnchfCartProduct_Click);
            // 
            // dgvchf
            // 
            this.dgvchf.BackgroundColor = System.Drawing.Color.Plum;
            this.dgvchf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvchf.Location = new System.Drawing.Point(364, 207);
            this.dgvchf.Name = "dgvchf";
            this.dgvchf.Size = new System.Drawing.Size(650, 317);
            this.dgvchf.TabIndex = 43;
            // 
            // btnchfViewProduct
            // 
            this.btnchfViewProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfViewProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfViewProduct.ForeColor = System.Drawing.Color.Black;
            this.btnchfViewProduct.Location = new System.Drawing.Point(370, 166);
            this.btnchfViewProduct.Name = "btnchfViewProduct";
            this.btnchfViewProduct.Size = new System.Drawing.Size(70, 35);
            this.btnchfViewProduct.TabIndex = 44;
            this.btnchfViewProduct.Text = "View Products";
            this.btnchfViewProduct.UseVisualStyleBackColor = false;
            this.btnchfViewProduct.Click += new System.EventHandler(this.btnchfViewProduct_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 48;
            this.label4.Text = "Enter Product ID :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tbchfProductId
            // 
            this.tbchfProductId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfProductId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfProductId.Location = new System.Drawing.Point(138, 309);
            this.tbchfProductId.Name = "tbchfProductId";
            this.tbchfProductId.Size = new System.Drawing.Size(145, 26);
            this.tbchfProductId.TabIndex = 47;
            // 
            // btnchfOrderNow
            // 
            this.btnchfOrderNow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfOrderNow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfOrderNow.ForeColor = System.Drawing.Color.Black;
            this.btnchfOrderNow.Location = new System.Drawing.Point(289, 352);
            this.btnchfOrderNow.Name = "btnchfOrderNow";
            this.btnchfOrderNow.Size = new System.Drawing.Size(67, 38);
            this.btnchfOrderNow.TabIndex = 49;
            this.btnchfOrderNow.Text = "Order Now";
            this.btnchfOrderNow.UseVisualStyleBackColor = false;
            this.btnchfOrderNow.Click += new System.EventHandler(this.btnchfOrderNow_Click);
            // 
            // btnchfAddCart
            // 
            this.btnchfAddCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfAddCart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfAddCart.ForeColor = System.Drawing.Color.Black;
            this.btnchfAddCart.Location = new System.Drawing.Point(944, 109);
            this.btnchfAddCart.Name = "btnchfAddCart";
            this.btnchfAddCart.Size = new System.Drawing.Size(67, 38);
            this.btnchfAddCart.TabIndex = 52;
            this.btnchfAddCart.Text = "Add Cart";
            this.btnchfAddCart.UseVisualStyleBackColor = false;
            this.btnchfAddCart.Click += new System.EventHandler(this.btnchfAddCart_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(657, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 20);
            this.label3.TabIndex = 51;
            this.label3.Text = "Enter Product ID :";
            // 
            // tbchfaddCart
            // 
            this.tbchfaddCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfaddCart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfaddCart.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfaddCart.Location = new System.Drawing.Point(793, 115);
            this.tbchfaddCart.Name = "tbchfaddCart";
            this.tbchfaddCart.Size = new System.Drawing.Size(145, 26);
            this.tbchfaddCart.TabIndex = 50;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 20);
            this.label5.TabIndex = 54;
            this.label5.Text = "Enter User ID :";
            // 
            // tbchfUserId
            // 
            this.tbchfUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfUserId.Location = new System.Drawing.Point(138, 264);
            this.tbchfUserId.Name = "tbchfUserId";
            this.tbchfUserId.Size = new System.Drawing.Size(145, 26);
            this.tbchfUserId.TabIndex = 53;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 360);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 20);
            this.label6.TabIndex = 56;
            this.label6.Text = "Payment :";
            // 
            // tbchfPayment
            // 
            this.tbchfPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfPayment.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfPayment.Location = new System.Drawing.Point(137, 357);
            this.tbchfPayment.Name = "tbchfPayment";
            this.tbchfPayment.Size = new System.Drawing.Size(145, 26);
            this.tbchfPayment.TabIndex = 55;
            this.tbchfPayment.TextChanged += new System.EventHandler(this.tbchfPayment_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(6, 495);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 29);
            this.button1.TabIndex = 57;
            this.button1.Text = "Contact";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CustomerHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1026, 527);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbchfPayment);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbchfUserId);
            this.Controls.Add(this.btnchfAddCart);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbchfaddCart);
            this.Controls.Add(this.btnchfOrderNow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbchfProductId);
            this.Controls.Add(this.btnchfViewProduct);
            this.Controls.Add(this.dgvchf);
            this.Controls.Add(this.btnchfCartProduct);
            this.Controls.Add(this.btnchfOrderProduct);
            this.Controls.Add(this.lrUserId);
            this.Controls.Add(this.tbchfSearch);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CustomerHomeForm";
            this.Text = "CustomerHomeForm";
            this.Load += new System.EventHandler(this.CustomerHomeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvchf)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.TextBox tbchfSearch;
        private System.Windows.Forms.Button btnchfOrderProduct;
        private System.Windows.Forms.Button btnchfCartProduct;
        private System.Windows.Forms.DataGridView dgvchf;
        private System.Windows.Forms.Button btnchfViewProduct;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbchfProductId;
        private System.Windows.Forms.Button btnchfOrderNow;
        private System.Windows.Forms.Button btnchfAddCart;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbchfaddCart;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbchfUserId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbchfPayment;
        private System.Windows.Forms.Button button1;
    }
}