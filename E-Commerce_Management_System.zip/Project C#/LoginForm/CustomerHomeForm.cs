﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class CustomerHomeForm : Form
    {
        public CustomerHomeForm()
        {
            InitializeComponent();
        }
        Product ad = new Product();
        OrderList ol = new OrderList();
        CartList cl = new CartList();

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            LoginForm lfc = new LoginForm();
            lfc.Show();
            this.Hide();
        }

        private void btnchfViewProduct_Click(object sender, EventArgs e)
        {
            DataTable dt = ad.showAllProduct();
            dgvchf.DataSource = dt;
        }

        private void btnchfSearchProduct_Click(object sender, EventArgs e)
        {

        }

        private void tbchfSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbchfSearch_TextChanged_1(object sender, EventArgs e)
        {
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\AddProduct.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(connection);
            string q = "Select * From AddProduct Where ProductName Like '%" + tbchfSearch.Text + "%'";
            SqlDataAdapter sda = new SqlDataAdapter(q, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvchf.DataSource = dt;
        }

        private void btnchfUpdateProfile_Click(object sender, EventArgs e)
        {
            OrderProductschf ops = new OrderProductschf();
            ops.Show();
            this.Hide();
        }

        private void btnchfCart_Click(object sender, EventArgs e)
        {

        }

        private void lrUserId_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void CustomerHomeForm_Load(object sender, EventArgs e)
        {

        }

        private void btnchmViewOrderProduct_Click(object sender, EventArgs e)
        {

        }

        public void clear1()
        {
            tbchfUserId.Clear();
            tbchfProductId.Clear();
            
        }
        public void clear2()
        {
            tbchfaddCart.Clear();
            
        }
        private void btnchfOrderNow_Click(object sender, EventArgs e)
        {
            try
            {
                ol.UserId = tbchfUserId.Text;
                ol.ProductId = tbchfProductId.Text;
                ol.Money = tbchfPayment.Text;
                
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = ol.AddOrder(ol);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear1();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btnchfAddCart_Click(object sender, EventArgs e)
        {
            try
            {
                cl.ProductId = tbchfaddCart.Text;

            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = cl.AddCart(cl);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear2();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btnchfCartProduct_Click(object sender, EventArgs e)
        {
            ViewCartProduct vcp = new ViewCartProduct();
            vcp.Show();
            this.Hide();
        }

        private void tbchfPayment_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("01603000591");
        }
    }
}
