﻿
namespace LoginForm
{
    partial class CustomerOperationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerOperationForm));
            this.gbcofGender = new System.Windows.Forms.GroupBox();
            this.rbcofgMale = new System.Windows.Forms.RadioButton();
            this.rbcofgFemale = new System.Windows.Forms.RadioButton();
            this.tbcofPassword = new System.Windows.Forms.TextBox();
            this.tbcofSecurityAns = new System.Windows.Forms.TextBox();
            this.tbcofAddress = new System.Windows.Forms.TextBox();
            this.tbcofAge = new System.Windows.Forms.TextBox();
            this.tbcofPhoneNo = new System.Windows.Forms.TextBox();
            this.tbcofEmail = new System.Windows.Forms.TextBox();
            this.tbcofName = new System.Windows.Forms.TextBox();
            this.tbcofUserId = new System.Windows.Forms.TextBox();
            this.lrPassword = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btncofBack = new System.Windows.Forms.Button();
            this.dgvCustomerOperation = new System.Windows.Forms.DataGridView();
            this.btncofShow = new System.Windows.Forms.Button();
            this.btncofAdd = new System.Windows.Forms.Button();
            this.dtpcofDoB = new System.Windows.Forms.DateTimePicker();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.searchBoxcof = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btncofDelete = new System.Windows.Forms.Button();
            this.btncofUpdate = new System.Windows.Forms.Button();
            this.gbcofGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerOperation)).BeginInit();
            this.SuspendLayout();
            // 
            // gbcofGender
            // 
            this.gbcofGender.BackColor = System.Drawing.Color.HotPink;
            this.gbcofGender.Controls.Add(this.rbcofgMale);
            this.gbcofGender.Controls.Add(this.rbcofgFemale);
            this.gbcofGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbcofGender.Location = new System.Drawing.Point(454, 186);
            this.gbcofGender.Name = "gbcofGender";
            this.gbcofGender.Size = new System.Drawing.Size(284, 28);
            this.gbcofGender.TabIndex = 84;
            this.gbcofGender.TabStop = false;
            this.gbcofGender.Text = "Gender : ";
            this.gbcofGender.Enter += new System.EventHandler(this.gbsofGender_Enter);
            // 
            // rbcofgMale
            // 
            this.rbcofgMale.AutoSize = true;
            this.rbcofgMale.BackColor = System.Drawing.Color.LightPink;
            this.rbcofgMale.Location = new System.Drawing.Point(83, 1);
            this.rbcofgMale.Name = "rbcofgMale";
            this.rbcofgMale.Size = new System.Drawing.Size(63, 24);
            this.rbcofgMale.TabIndex = 20;
            this.rbcofgMale.TabStop = true;
            this.rbcofgMale.Text = "Male";
            this.rbcofgMale.UseVisualStyleBackColor = false;
            this.rbcofgMale.CheckedChanged += new System.EventHandler(this.rbcofgMale_CheckedChanged);
            // 
            // rbcofgFemale
            // 
            this.rbcofgFemale.AutoSize = true;
            this.rbcofgFemale.BackColor = System.Drawing.Color.LightPink;
            this.rbcofgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbcofgFemale.Name = "rbcofgFemale";
            this.rbcofgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbcofgFemale.TabIndex = 21;
            this.rbcofgFemale.TabStop = true;
            this.rbcofgFemale.Text = "Female";
            this.rbcofgFemale.UseVisualStyleBackColor = false;
            this.rbcofgFemale.CheckedChanged += new System.EventHandler(this.rbcofgFemale_CheckedChanged);
            // 
            // tbcofPassword
            // 
            this.tbcofPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofPassword.Location = new System.Drawing.Point(558, 107);
            this.tbcofPassword.Name = "tbcofPassword";
            this.tbcofPassword.PasswordChar = '*';
            this.tbcofPassword.Size = new System.Drawing.Size(139, 26);
            this.tbcofPassword.TabIndex = 82;
            this.tbcofPassword.UseSystemPasswordChar = true;
            // 
            // tbcofSecurityAns
            // 
            this.tbcofSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofSecurityAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofSecurityAns.Location = new System.Drawing.Point(558, 70);
            this.tbcofSecurityAns.Name = "tbcofSecurityAns";
            this.tbcofSecurityAns.Size = new System.Drawing.Size(139, 26);
            this.tbcofSecurityAns.TabIndex = 81;
            // 
            // tbcofAddress
            // 
            this.tbcofAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofAddress.Location = new System.Drawing.Point(542, 13);
            this.tbcofAddress.Name = "tbcofAddress";
            this.tbcofAddress.Size = new System.Drawing.Size(139, 26);
            this.tbcofAddress.TabIndex = 80;
            // 
            // tbcofAge
            // 
            this.tbcofAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofAge.Location = new System.Drawing.Point(209, 183);
            this.tbcofAge.Name = "tbcofAge";
            this.tbcofAge.Size = new System.Drawing.Size(139, 26);
            this.tbcofAge.TabIndex = 79;
            // 
            // tbcofPhoneNo
            // 
            this.tbcofPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofPhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofPhoneNo.Location = new System.Drawing.Point(209, 145);
            this.tbcofPhoneNo.Name = "tbcofPhoneNo";
            this.tbcofPhoneNo.Size = new System.Drawing.Size(139, 26);
            this.tbcofPhoneNo.TabIndex = 78;
            // 
            // tbcofEmail
            // 
            this.tbcofEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofEmail.Location = new System.Drawing.Point(209, 103);
            this.tbcofEmail.Name = "tbcofEmail";
            this.tbcofEmail.Size = new System.Drawing.Size(139, 26);
            this.tbcofEmail.TabIndex = 77;
            // 
            // tbcofName
            // 
            this.tbcofName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofName.Location = new System.Drawing.Point(209, 67);
            this.tbcofName.Name = "tbcofName";
            this.tbcofName.Size = new System.Drawing.Size(139, 26);
            this.tbcofName.TabIndex = 76;
            // 
            // tbcofUserId
            // 
            this.tbcofUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbcofUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcofUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbcofUserId.Location = new System.Drawing.Point(209, 26);
            this.tbcofUserId.Name = "tbcofUserId";
            this.tbcofUserId.Size = new System.Drawing.Size(139, 26);
            this.tbcofUserId.TabIndex = 75;
            // 
            // lrPassword
            // 
            this.lrPassword.AutoSize = true;
            this.lrPassword.BackColor = System.Drawing.Color.Transparent;
            this.lrPassword.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPassword.Location = new System.Drawing.Point(466, 109);
            this.lrPassword.Name = "lrPassword";
            this.lrPassword.Size = new System.Drawing.Size(90, 20);
            this.lrPassword.TabIndex = 73;
            this.lrPassword.Text = "Password : ";
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(418, 71);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 72;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(418, 42);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 71;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(462, 11);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 70;
            this.lrAddress.Text = "Address : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(159, 184);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 69;
            this.lrAge.Text = "Age : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(117, 147);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 68;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(151, 107);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 67;
            this.lrEmail.Text = "Email : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(146, 69);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 66;
            this.lrName.Text = "Name : ";
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(138, 28);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 65;
            this.lrUserId.Text = "User Id : ";
            // 
            // btncofBack
            // 
            this.btncofBack.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncofBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncofBack.Location = new System.Drawing.Point(731, 236);
            this.btncofBack.Name = "btncofBack";
            this.btncofBack.Size = new System.Drawing.Size(75, 31);
            this.btncofBack.TabIndex = 85;
            this.btncofBack.Text = "Back";
            this.btncofBack.UseVisualStyleBackColor = false;
            this.btncofBack.Click += new System.EventHandler(this.btncofBack_Click);
            // 
            // dgvCustomerOperation
            // 
            this.dgvCustomerOperation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvCustomerOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerOperation.Location = new System.Drawing.Point(70, 284);
            this.dgvCustomerOperation.Name = "dgvCustomerOperation";
            this.dgvCustomerOperation.Size = new System.Drawing.Size(752, 187);
            this.dgvCustomerOperation.TabIndex = 86;
            this.dgvCustomerOperation.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvCustomerOperation_RowHeaderMouseClick);
            // 
            // btncofShow
            // 
            this.btncofShow.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncofShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncofShow.Location = new System.Drawing.Point(173, 236);
            this.btncofShow.Name = "btncofShow";
            this.btncofShow.Size = new System.Drawing.Size(75, 31);
            this.btncofShow.TabIndex = 88;
            this.btncofShow.Text = "Show";
            this.btncofShow.UseVisualStyleBackColor = false;
            this.btncofShow.Click += new System.EventHandler(this.btncofShow_Click);
            // 
            // btncofAdd
            // 
            this.btncofAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncofAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncofAdd.Location = new System.Drawing.Point(80, 236);
            this.btncofAdd.Name = "btncofAdd";
            this.btncofAdd.Size = new System.Drawing.Size(75, 31);
            this.btncofAdd.TabIndex = 87;
            this.btncofAdd.Text = "Add";
            this.btncofAdd.UseVisualStyleBackColor = false;
            this.btncofAdd.Click += new System.EventHandler(this.btncofAdd_Click);
            // 
            // dtpcofDoB
            // 
            this.dtpcofDoB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpcofDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpcofDoB.Location = new System.Drawing.Point(558, 147);
            this.dtpcofDoB.Name = "dtpcofDoB";
            this.dtpcofDoB.Size = new System.Drawing.Size(239, 22);
            this.dtpcofDoB.TabIndex = 90;
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(443, 148);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(114, 20);
            this.lrAdminType.TabIndex = 89;
            this.lrAdminType.Text = "Date Of Birth : ";
            // 
            // searchBoxcof
            // 
            this.searchBoxcof.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchBoxcof.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBoxcof.ForeColor = System.Drawing.SystemColors.WindowText;
            this.searchBoxcof.Location = new System.Drawing.Point(536, 238);
            this.searchBoxcof.Name = "searchBoxcof";
            this.searchBoxcof.Size = new System.Drawing.Size(177, 26);
            this.searchBoxcof.TabIndex = 94;
            this.searchBoxcof.TextChanged += new System.EventHandler(this.searchBoxcof_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(463, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 93;
            this.label1.Text = "Search : ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btncofDelete
            // 
            this.btncofDelete.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncofDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncofDelete.Location = new System.Drawing.Point(359, 236);
            this.btncofDelete.Name = "btncofDelete";
            this.btncofDelete.Size = new System.Drawing.Size(75, 31);
            this.btncofDelete.TabIndex = 92;
            this.btncofDelete.Text = "Delete";
            this.btncofDelete.UseVisualStyleBackColor = false;
            this.btncofDelete.Click += new System.EventHandler(this.btncofDelete_Click);
            // 
            // btncofUpdate
            // 
            this.btncofUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncofUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncofUpdate.Location = new System.Drawing.Point(264, 236);
            this.btncofUpdate.Name = "btncofUpdate";
            this.btncofUpdate.Size = new System.Drawing.Size(75, 31);
            this.btncofUpdate.TabIndex = 91;
            this.btncofUpdate.Text = "Update";
            this.btncofUpdate.UseVisualStyleBackColor = false;
            this.btncofUpdate.Click += new System.EventHandler(this.btncofUpdate_Click);
            // 
            // CustomerOperationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(885, 495);
            this.Controls.Add(this.searchBoxcof);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncofDelete);
            this.Controls.Add(this.btncofUpdate);
            this.Controls.Add(this.dtpcofDoB);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.btncofShow);
            this.Controls.Add(this.btncofAdd);
            this.Controls.Add(this.dgvCustomerOperation);
            this.Controls.Add(this.btncofBack);
            this.Controls.Add(this.gbcofGender);
            this.Controls.Add(this.tbcofPassword);
            this.Controls.Add(this.tbcofSecurityAns);
            this.Controls.Add(this.tbcofAddress);
            this.Controls.Add(this.tbcofAge);
            this.Controls.Add(this.tbcofPhoneNo);
            this.Controls.Add(this.tbcofEmail);
            this.Controls.Add(this.tbcofName);
            this.Controls.Add(this.tbcofUserId);
            this.Controls.Add(this.lrPassword);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CustomerOperationForm";
            this.Text = "CustomerOperationForm";
            this.Load += new System.EventHandler(this.CustomerOperationForm_Load);
            this.gbcofGender.ResumeLayout(false);
            this.gbcofGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerOperation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbcofGender;
        private System.Windows.Forms.RadioButton rbcofgMale;
        private System.Windows.Forms.RadioButton rbcofgFemale;
        private System.Windows.Forms.TextBox tbcofPassword;
        private System.Windows.Forms.TextBox tbcofSecurityAns;
        private System.Windows.Forms.TextBox tbcofAddress;
        private System.Windows.Forms.TextBox tbcofAge;
        private System.Windows.Forms.TextBox tbcofPhoneNo;
        private System.Windows.Forms.TextBox tbcofEmail;
        private System.Windows.Forms.TextBox tbcofName;
        private System.Windows.Forms.TextBox tbcofUserId;
        private System.Windows.Forms.Label lrPassword;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btncofBack;
        private System.Windows.Forms.DataGridView dgvCustomerOperation;
        private System.Windows.Forms.Button btncofShow;
        private System.Windows.Forms.Button btncofAdd;
        private System.Windows.Forms.DateTimePicker dtpcofDoB;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.TextBox searchBoxcof;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btncofDelete;
        private System.Windows.Forms.Button btncofUpdate;
    }
}