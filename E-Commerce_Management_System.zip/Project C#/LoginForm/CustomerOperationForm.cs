﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class CustomerOperationForm : Form
    {
        public CustomerOperationForm()
        {
            InitializeComponent();
        }

        Customer cu = new Customer();
        private void CustomerOperationForm_Load(object sender, EventArgs e)
        {

        }

        private void gbsofGender_Enter(object sender, EventArgs e)
        {

        }

        private void btncofBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        public void clear()
        {
            tbcofUserId.Clear();
            tbcofName.Clear();
            tbcofEmail.Clear();
            tbcofPhoneNo.Clear();
            tbcofAge.Clear();
            tbcofAddress.Clear();
            tbcofSecurityAns.Clear();
            tbcofPassword.Clear();
        }

        private void btncofAdd_Click(object sender, EventArgs e)
        {
            try
            {
                cu.UserId = tbcofUserId.Text;
                cu.Name = tbcofName.Text;
                cu.Email = tbcofEmail.Text;
                cu.PhoneNo = tbcofPhoneNo.Text;
                cu.Age = Convert.ToInt32(tbcofAge.Text);
                cu.Address = tbcofAddress.Text;
                cu.SecurityAns = tbcofSecurityAns.Text;
                cu.Password = tbcofPassword.Text;
                cu.DoB = dtpcofDoB.Value.ToString();
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = cu.InsertCustomer(cu);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btncofShow_Click(object sender, EventArgs e)
        {
            DataTable dt = cu.showAllCustomerList();
            dgvCustomerOperation.DataSource = dt;
        }

        private void rbcofgMale_CheckedChanged(object sender, EventArgs e)
        {
            cu.Gender = "Male";
        }

        private void rbcofgFemale_CheckedChanged(object sender, EventArgs e)
        {
            cu.Gender = "Female";
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void dgvCustomerOperation_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int row_index = e.RowIndex;
            tbcofUserId.Text = dgvCustomerOperation.Rows[row_index].Cells[0].Value.ToString();
            tbcofName.Text = dgvCustomerOperation.Rows[row_index].Cells[1].Value.ToString();
            tbcofEmail.Text = dgvCustomerOperation.Rows[row_index].Cells[2].Value.ToString();
            tbcofPhoneNo.Text = dgvCustomerOperation.Rows[row_index].Cells[3].Value.ToString();
            tbcofAge.Text = dgvCustomerOperation.Rows[row_index].Cells[4].Value.ToString();
            tbcofAddress.Text = dgvCustomerOperation.Rows[row_index].Cells[5].Value.ToString();
            tbcofSecurityAns.Text = dgvCustomerOperation.Rows[row_index].Cells[6].Value.ToString();
            tbcofPassword.Text = dgvCustomerOperation.Rows[row_index].Cells[7].Value.ToString();
            dtpcofDoB.Text = dgvCustomerOperation.Rows[row_index].Cells[8].Value.ToString();
            gbcofGender.Text = dgvCustomerOperation.Rows[row_index].Cells[9].Value.ToString();
        }

        private void btncofDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cu.UserId = tbcofUserId.Text;

                bool success = cu.deleteCustomerOperation(cu);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = cu.showAllCustomerList();
            dgvCustomerOperation.DataSource = dt;
        }

        private void btncofUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                cu.UserId = tbcofUserId.Text;
                cu.Name = tbcofName.Text;
                cu.Email = tbcofEmail.Text;
                cu.PhoneNo = tbcofPhoneNo.Text;
                cu.Age = Convert.ToInt32(tbcofAge.Text);
                cu.Address = tbcofAddress.Text;
                cu.SecurityAns = tbcofSecurityAns.Text;
                cu.Password = tbcofPassword.Text;
                cu.DoB = dtpcofDoB.Value.ToString();

                bool success = cu.updateCustomerOperation(cu);
                if (success == true)
                {
                    MessageBox.Show("Successfully Updated!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = cu.showAllCustomerList();
            dgvCustomerOperation.DataSource = dt;
        }

        private void searchBoxcof_TextChanged(object sender, EventArgs e)
        {
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\CustomerOperation.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(connection);
            string q = "Select * From CustomerOperation Where Name Like '%" + searchBoxcof.Text + "%'";
            SqlDataAdapter sda = new SqlDataAdapter(q, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvCustomerOperation.DataSource = dt;
        }
    }
}
