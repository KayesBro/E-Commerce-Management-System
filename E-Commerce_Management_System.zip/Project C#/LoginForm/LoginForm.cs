﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        string connection1 = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\AdminOperation.mdf;Integrated Security=True;Connect Timeout=30";
        string connection2 = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\SellerOperation.mdf;Integrated Security=True;Connect Timeout=30";
        string connection3 = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\CustomerOperation.mdf;Integrated Security=True;Connect Timeout=30";
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnShow_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            SqlConnection sqc1 = new SqlConnection(connection1);
            string q1 = "Select count(*) From AdminOperation where UserId='" + tbUserId.Text + "' and Password='" + tbPassword.Text + "'";
            SqlDataAdapter sqd1 = new SqlDataAdapter(q1, sqc1);
            DataTable dt1 = new DataTable();
            sqd1.Fill(dt1);
            
            SqlConnection sqc2 = new SqlConnection(connection2);
            string q2 = "Select count(*) From SellerOperation where UserId='" + tbUserId.Text + "' and Password='" + tbPassword.Text + "'";
            SqlDataAdapter sqd2 = new SqlDataAdapter(q2, sqc2);
            DataTable dt2 = new DataTable();
            sqd2.Fill(dt2);
            
            SqlConnection sqc3 = new SqlConnection(connection3);
            string q3 = "Select count(*) From CustomerOperation where UserId='" + tbUserId.Text + "' and Password='" + tbPassword.Text + "'";
            SqlDataAdapter sqd3 = new SqlDataAdapter(q3, sqc3);
            DataTable dt3 = new DataTable();
            sqd3.Fill(dt3);

            if (dt1.Rows[0][0].ToString() == "1")
            {
                AdminHomeForm ahfl = new AdminHomeForm();
                ahfl.Show();
                this.Hide();
            }
            else if (dt2.Rows[0][0].ToString() == "1")
            {
                SellerHomeForm shfl = new SellerHomeForm();
                shfl.Show();
                this.Hide();
            }
           else if (dt3.Rows[0][0].ToString() == "1")
            {
                CustomerHomeForm chfl = new CustomerHomeForm();
                chfl.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid User info");
            }


        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            RegistrationForm rf = new RegistrationForm();
            rf.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tbUserId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnShow_Click_2(object sender, EventArgs e)
        {
            tbPassword.UseSystemPasswordChar = false;
        }
    }
}
