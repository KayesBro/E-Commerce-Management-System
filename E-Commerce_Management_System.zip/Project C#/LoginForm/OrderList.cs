﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace LoginForm
{
    class OrderList
    {
        public string UserId { get; set; }
        public string ProductId { get; set; }
        public string Money { get; set; }

        string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\OrderList.mdf;Integrated Security=True;Connect Timeout=30";

        public DataTable showAllOrderList()
        {
            SqlConnection sqc = new SqlConnection(connection);
            string q = "Select * From OrderList";
            SqlDataAdapter sqd = new SqlDataAdapter(q, sqc);
            DataTable dt = new DataTable();
            sqd.Fill(dt);

            return dt;
        }

        public bool AddOrder(OrderList a)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Insert into OrderList (UserId,ProductId,Money) Values (@UserId,@ProductId,@Money)";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", a.UserId);
                cmd.Parameters.AddWithValue("@ProductId", a.ProductId);
                cmd.Parameters.AddWithValue("@Money", a.Money);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }

            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool deleteOrder(OrderList s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Delete from OrderList Where ProductId=@ProductId";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@ProductId", s.ProductId);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }


    }
}
