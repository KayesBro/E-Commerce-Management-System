﻿
namespace LoginForm
{
    partial class OrderProductschf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderProductschf));
            this.btnchfopsShow = new System.Windows.Forms.Button();
            this.btnchfopsBack = new System.Windows.Forms.Button();
            this.dgvchfOrderProducts = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvchfOrderProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // btnchfopsShow
            // 
            this.btnchfopsShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfopsShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfopsShow.ForeColor = System.Drawing.Color.Black;
            this.btnchfopsShow.Location = new System.Drawing.Point(283, 22);
            this.btnchfopsShow.Name = "btnchfopsShow";
            this.btnchfopsShow.Size = new System.Drawing.Size(90, 40);
            this.btnchfopsShow.TabIndex = 7;
            this.btnchfopsShow.Text = "Show";
            this.btnchfopsShow.UseVisualStyleBackColor = false;
            this.btnchfopsShow.Click += new System.EventHandler(this.btnchfopsShow_Click);
            // 
            // btnchfopsBack
            // 
            this.btnchfopsBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfopsBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfopsBack.ForeColor = System.Drawing.Color.Black;
            this.btnchfopsBack.Location = new System.Drawing.Point(401, 22);
            this.btnchfopsBack.Name = "btnchfopsBack";
            this.btnchfopsBack.Size = new System.Drawing.Size(90, 40);
            this.btnchfopsBack.TabIndex = 6;
            this.btnchfopsBack.Text = "Back";
            this.btnchfopsBack.UseVisualStyleBackColor = false;
            this.btnchfopsBack.Click += new System.EventHandler(this.btnchfopsBack_Click);
            // 
            // dgvchfOrderProducts
            // 
            this.dgvchfOrderProducts.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvchfOrderProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvchfOrderProducts.Location = new System.Drawing.Point(26, 84);
            this.dgvchfOrderProducts.Name = "dgvchfOrderProducts";
            this.dgvchfOrderProducts.Size = new System.Drawing.Size(465, 419);
            this.dgvchfOrderProducts.TabIndex = 5;
            this.dgvchfOrderProducts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvchfOrderProducts_CellContentClick);
            // 
            // OrderProductschf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(512, 515);
            this.Controls.Add(this.btnchfopsShow);
            this.Controls.Add(this.btnchfopsBack);
            this.Controls.Add(this.dgvchfOrderProducts);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OrderProductschf";
            this.Text = "OrderProducts";
            ((System.ComponentModel.ISupportInitialize)(this.dgvchfOrderProducts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnchfopsShow;
        private System.Windows.Forms.Button btnchfopsBack;
        private System.Windows.Forms.DataGridView dgvchfOrderProducts;
    }
}