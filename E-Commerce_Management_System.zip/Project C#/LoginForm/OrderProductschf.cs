﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    public partial class OrderProductschf : Form
    {
        public OrderProductschf()
        {
            InitializeComponent();
        }
        OrderList ol = new OrderList();

        private void dgvchfOrderProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnchfopsShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ol.showAllOrderList();
            dgvchfOrderProducts.DataSource = dt;
        }

        private void btnchfopsBack_Click(object sender, EventArgs e)
        {
            CustomerHomeForm chf = new CustomerHomeForm();
            chf.Show();
            this.Hide();
        }
    }
}
