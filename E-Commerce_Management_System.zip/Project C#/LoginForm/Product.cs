﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    class Product
    {
        public string ProductID { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public Double Price { get; set; }
        public int StockQuantity { get; set; }
        public string Details { get; set; }

        string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\AddProduct.mdf;Integrated Security=True;Connect Timeout=30";
        public DataTable showAllProduct()
        {
            SqlConnection sqc = new SqlConnection(connection);
            string q = "Select * From AddProduct";
            SqlDataAdapter sqd = new SqlDataAdapter(q, sqc);
            DataTable dt = new DataTable();
            sqd.Fill(dt);

            return dt;
        }

        public bool AddProduct(Product s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Insert into AddProduct (ProductID,ProductName,Category,Price,StockQuantity,Details) Values (@ProductID,@ProductName,@Category,@Price,@StockQuantity,@Details)";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@ProductID", s.ProductID);
                cmd.Parameters.AddWithValue("@ProductName", s.ProductName);
                cmd.Parameters.AddWithValue("@Category", s.Category);
                cmd.Parameters.AddWithValue("@Price", s.Price);
                cmd.Parameters.AddWithValue("@StockQuantity", s.StockQuantity);
                cmd.Parameters.AddWithValue("@Details", s.Details);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool deleteProductOperation(Product s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Delete from AddProduct Where ProductID=@ProductID";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@ProductID", s.ProductID);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }


    }
}
