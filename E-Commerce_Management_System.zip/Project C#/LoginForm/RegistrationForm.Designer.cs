﻿
namespace LoginForm
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationForm));
            this.lrUserId = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.lrPassword = new System.Windows.Forms.Label();
            this.tbrUserId = new System.Windows.Forms.TextBox();
            this.tbrName = new System.Windows.Forms.TextBox();
            this.tbrEmail = new System.Windows.Forms.TextBox();
            this.tbrPhoneNo = new System.Windows.Forms.TextBox();
            this.tbrAge = new System.Windows.Forms.TextBox();
            this.tbrAddress = new System.Windows.Forms.TextBox();
            this.tbrSecurityAns = new System.Windows.Forms.TextBox();
            this.tbrPassword = new System.Windows.Forms.TextBox();
            this.rbrgMale = new System.Windows.Forms.RadioButton();
            this.rbrgFemale = new System.Windows.Forms.RadioButton();
            this.btnrSubmit = new System.Windows.Forms.Button();
            this.btnrBack = new System.Windows.Forms.Button();
            this.gbrGender = new System.Windows.Forms.GroupBox();
            this.lrdateofbirth = new System.Windows.Forms.Label();
            this.dtprfDoB = new System.Windows.Forms.DateTimePicker();
            this.gbrGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(360, 9);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 0;
            this.lrUserId.Text = "User Id : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(368, 50);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 1;
            this.lrName.Text = "Name : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(373, 88);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 2;
            this.lrEmail.Text = "Email : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(339, 128);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 3;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(381, 165);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 4;
            this.lrAge.Text = "Age : ";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(351, 205);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 5;
            this.lrAddress.Text = "Address : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(291, 244);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 6;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            this.rityQuestion.Click += new System.EventHandler(this.rityQuestion_Click);
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(291, 269);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 7;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // lrPassword
            // 
            this.lrPassword.AutoSize = true;
            this.lrPassword.BackColor = System.Drawing.Color.Transparent;
            this.lrPassword.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPassword.Location = new System.Drawing.Point(339, 307);
            this.lrPassword.Name = "lrPassword";
            this.lrPassword.Size = new System.Drawing.Size(90, 20);
            this.lrPassword.TabIndex = 8;
            this.lrPassword.Text = "Password : ";
            // 
            // tbrUserId
            // 
            this.tbrUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrUserId.Location = new System.Drawing.Point(431, 10);
            this.tbrUserId.Name = "tbrUserId";
            this.tbrUserId.Size = new System.Drawing.Size(139, 20);
            this.tbrUserId.TabIndex = 11;
            this.tbrUserId.TextChanged += new System.EventHandler(this.tbrUserId_TextChanged);
            // 
            // tbrName
            // 
            this.tbrName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrName.Location = new System.Drawing.Point(431, 52);
            this.tbrName.Name = "tbrName";
            this.tbrName.Size = new System.Drawing.Size(139, 20);
            this.tbrName.TabIndex = 12;
            // 
            // tbrEmail
            // 
            this.tbrEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrEmail.Location = new System.Drawing.Point(431, 88);
            this.tbrEmail.Name = "tbrEmail";
            this.tbrEmail.Size = new System.Drawing.Size(139, 20);
            this.tbrEmail.TabIndex = 13;
            // 
            // tbrPhoneNo
            // 
            this.tbrPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrPhoneNo.Location = new System.Drawing.Point(431, 130);
            this.tbrPhoneNo.Name = "tbrPhoneNo";
            this.tbrPhoneNo.Size = new System.Drawing.Size(139, 20);
            this.tbrPhoneNo.TabIndex = 14;
            // 
            // tbrAge
            // 
            this.tbrAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrAge.Location = new System.Drawing.Point(431, 167);
            this.tbrAge.Name = "tbrAge";
            this.tbrAge.Size = new System.Drawing.Size(139, 20);
            this.tbrAge.TabIndex = 15;
            // 
            // tbrAddress
            // 
            this.tbrAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrAddress.Location = new System.Drawing.Point(431, 207);
            this.tbrAddress.Name = "tbrAddress";
            this.tbrAddress.Size = new System.Drawing.Size(139, 20);
            this.tbrAddress.TabIndex = 16;
            // 
            // tbrSecurityAns
            // 
            this.tbrSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrSecurityAns.Location = new System.Drawing.Point(431, 271);
            this.tbrSecurityAns.Name = "tbrSecurityAns";
            this.tbrSecurityAns.Size = new System.Drawing.Size(139, 20);
            this.tbrSecurityAns.TabIndex = 17;
            // 
            // tbrPassword
            // 
            this.tbrPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrPassword.Location = new System.Drawing.Point(431, 309);
            this.tbrPassword.Name = "tbrPassword";
            this.tbrPassword.Size = new System.Drawing.Size(139, 20);
            this.tbrPassword.TabIndex = 18;
            this.tbrPassword.UseSystemPasswordChar = true;
            // 
            // rbrgMale
            // 
            this.rbrgMale.AutoSize = true;
            this.rbrgMale.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rbrgMale.Location = new System.Drawing.Point(83, 1);
            this.rbrgMale.Name = "rbrgMale";
            this.rbrgMale.Size = new System.Drawing.Size(63, 24);
            this.rbrgMale.TabIndex = 20;
            this.rbrgMale.TabStop = true;
            this.rbrgMale.Text = "Male";
            this.rbrgMale.UseVisualStyleBackColor = false;
            this.rbrgMale.CheckedChanged += new System.EventHandler(this.rbgMale_CheckedChanged);
            // 
            // rbrgFemale
            // 
            this.rbrgFemale.AutoSize = true;
            this.rbrgFemale.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rbrgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbrgFemale.Name = "rbrgFemale";
            this.rbrgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbrgFemale.TabIndex = 21;
            this.rbrgFemale.TabStop = true;
            this.rbrgFemale.Text = "Female";
            this.rbrgFemale.UseVisualStyleBackColor = false;
            this.rbrgFemale.CheckedChanged += new System.EventHandler(this.rbgFemale_CheckedChanged);
            // 
            // btnrSubmit
            // 
            this.btnrSubmit.BackColor = System.Drawing.Color.Chartreuse;
            this.btnrSubmit.Location = new System.Drawing.Point(354, 452);
            this.btnrSubmit.Name = "btnrSubmit";
            this.btnrSubmit.Size = new System.Drawing.Size(75, 32);
            this.btnrSubmit.TabIndex = 22;
            this.btnrSubmit.Text = "Submit";
            this.btnrSubmit.UseVisualStyleBackColor = false;
            this.btnrSubmit.Click += new System.EventHandler(this.btnrSubmit_Click);
            // 
            // btnrBack
            // 
            this.btnrBack.BackColor = System.Drawing.Color.Chartreuse;
            this.btnrBack.Location = new System.Drawing.Point(472, 452);
            this.btnrBack.Name = "btnrBack";
            this.btnrBack.Size = new System.Drawing.Size(75, 32);
            this.btnrBack.TabIndex = 23;
            this.btnrBack.Text = "Back";
            this.btnrBack.UseVisualStyleBackColor = false;
            this.btnrBack.Click += new System.EventHandler(this.btnrBack_Click);
            // 
            // gbrGender
            // 
            this.gbrGender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gbrGender.Controls.Add(this.rbrgMale);
            this.gbrGender.Controls.Add(this.rbrgFemale);
            this.gbrGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbrGender.Location = new System.Drawing.Point(327, 384);
            this.gbrGender.Name = "gbrGender";
            this.gbrGender.Size = new System.Drawing.Size(284, 28);
            this.gbrGender.TabIndex = 24;
            this.gbrGender.TabStop = false;
            this.gbrGender.Text = "Gender : ";
            this.gbrGender.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lrdateofbirth
            // 
            this.lrdateofbirth.AutoSize = true;
            this.lrdateofbirth.BackColor = System.Drawing.Color.Transparent;
            this.lrdateofbirth.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrdateofbirth.Location = new System.Drawing.Point(315, 342);
            this.lrdateofbirth.Name = "lrdateofbirth";
            this.lrdateofbirth.Size = new System.Drawing.Size(114, 20);
            this.lrdateofbirth.TabIndex = 9;
            this.lrdateofbirth.Text = "Date Of Birth : ";
            // 
            // dtprfDoB
            // 
            this.dtprfDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtprfDoB.Location = new System.Drawing.Point(431, 342);
            this.dtprfDoB.Name = "dtprfDoB";
            this.dtprfDoB.Size = new System.Drawing.Size(241, 22);
            this.dtprfDoB.TabIndex = 25;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(747, 523);
            this.Controls.Add(this.dtprfDoB);
            this.Controls.Add(this.gbrGender);
            this.Controls.Add(this.btnrBack);
            this.Controls.Add(this.btnrSubmit);
            this.Controls.Add(this.tbrPassword);
            this.Controls.Add(this.tbrSecurityAns);
            this.Controls.Add(this.tbrAddress);
            this.Controls.Add(this.tbrAge);
            this.Controls.Add(this.tbrPhoneNo);
            this.Controls.Add(this.tbrEmail);
            this.Controls.Add(this.tbrName);
            this.Controls.Add(this.tbrUserId);
            this.Controls.Add(this.lrdateofbirth);
            this.Controls.Add(this.lrPassword);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.gbrGender.ResumeLayout(false);
            this.gbrGender.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label lrPassword;
        private System.Windows.Forms.TextBox tbrUserId;
        private System.Windows.Forms.TextBox tbrName;
        private System.Windows.Forms.TextBox tbrEmail;
        private System.Windows.Forms.TextBox tbrPhoneNo;
        private System.Windows.Forms.TextBox tbrAge;
        private System.Windows.Forms.TextBox tbrAddress;
        private System.Windows.Forms.TextBox tbrSecurityAns;
        private System.Windows.Forms.TextBox tbrPassword;
        private System.Windows.Forms.RadioButton rbrgMale;
        private System.Windows.Forms.RadioButton rbrgFemale;
        private System.Windows.Forms.Button btnrSubmit;
        private System.Windows.Forms.Button btnrBack;
        private System.Windows.Forms.GroupBox gbrGender;
        private System.Windows.Forms.Label lrdateofbirth;
        private System.Windows.Forms.DateTimePicker dtprfDoB;
    }
}