﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }
        Customer cu = new Customer();
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void rityQuestion_Click(object sender, EventArgs e)
        {

        }

        private void btnrBack_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        
        private void rbgMale_CheckedChanged(object sender, EventArgs e)
        {
            cu.Gender = "Male";
        }

        private void rbgFemale_CheckedChanged(object sender, EventArgs e)
        {
            cu.Gender = "Female";
        }

        private void tbrUserId_TextChanged(object sender, EventArgs e)
        {

        }

        public void clear()
        {
            tbrUserId.Clear();
            tbrName.Clear();
            tbrEmail.Clear();
            tbrPhoneNo.Clear();
            tbrAge.Clear();
            tbrAddress.Clear();
            tbrSecurityAns.Clear();
            tbrPassword.Clear();
        }

        private void btnrSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                cu.UserId = tbrUserId.Text;
                cu.Name = tbrName.Text;
                cu.Email = tbrEmail.Text;
                cu.PhoneNo = tbrPhoneNo.Text;
                cu.Age = Convert.ToInt32(tbrAge.Text);
                cu.Address = tbrAddress.Text;
                cu.SecurityAns = tbrSecurityAns.Text;
                cu.Password = tbrPassword.Text;
                cu.DoB = dtprfDoB.Value.ToString();
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = cu.InsertCustomer(cu);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }
    }
}
