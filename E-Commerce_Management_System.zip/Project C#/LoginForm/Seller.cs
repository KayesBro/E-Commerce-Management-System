﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace LoginForm
{
    class Seller
    {
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string SecurityAns { get; set; }
        public string Password { get; set; }
        public string DoB { get; set; }
        public string Gender { get; set; }

        string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\SellerOperation.mdf;Integrated Security=True;Connect Timeout=30";

        public DataTable showAllSellerList()
        {
            SqlConnection sqc = new SqlConnection(connection);
            string q = "Select * From SellerOperation";
            SqlDataAdapter sqd = new SqlDataAdapter(q, sqc);
            DataTable dt = new DataTable();
            sqd.Fill(dt);

            return dt;
        }

        public bool InsertSeller(Seller a)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Insert into SellerOperation (UserId,Name,Email,PhoneNO,Age,Address,SecurityAns,Password,DoB,Gender) Values (@UserId,@Name,@Email,@PhoneNO,@Age,@Address,@SecurityAns,@Password,@DoB,@Gender)";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", a.UserId);
                cmd.Parameters.AddWithValue("@Name", a.Name);
                cmd.Parameters.AddWithValue("@Email", a.Email);
                cmd.Parameters.AddWithValue("@PhoneNO", a.PhoneNo);
                cmd.Parameters.AddWithValue("@Age", a.Age);
                cmd.Parameters.AddWithValue("@Address", a.Address);
                cmd.Parameters.AddWithValue("@SecurityAns", a.SecurityAns);
                cmd.Parameters.AddWithValue("@Password", a.Password);
                cmd.Parameters.AddWithValue("@DoB", a.DoB);
                cmd.Parameters.AddWithValue("@Gender", a.Gender);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }

           }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool updateSellerOperation(Seller a1)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
             {
                string q = "Update SellerOperation set  Name=@Name, Email=@Email, PhoneNO=@PhoneNO, Age=@Age, Address=@Address, SecurityAns=@SecurityAns, Password=@Password, " +
                    "DoB=@DoB, Gender=@Gender Where UserId=@UserId";

            sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", a1.UserId);
                cmd.Parameters.AddWithValue("@Name", a1.Name);
                cmd.Parameters.AddWithValue("@Email", a1.Email);
                cmd.Parameters.AddWithValue("@PhoneNO", a1.PhoneNo);
                cmd.Parameters.AddWithValue("@Age", a1.Age);
                cmd.Parameters.AddWithValue("@Address", a1.Address);
                cmd.Parameters.AddWithValue("@SecurityAns", a1.SecurityAns);
                cmd.Parameters.AddWithValue("@Password", a1.Password);
                cmd.Parameters.AddWithValue("@DoB", a1.DoB);
                cmd.Parameters.AddWithValue("@Gender", a1.Gender);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

        public bool deleteSellerOperation(Seller s)
        {
            bool success = false;
            SqlConnection sqc = new SqlConnection(connection);
            try
            {
                string q = "Delete from SellerOperation Where UserId=@UserId";

                sqc.Open();
                SqlCommand cmd = new SqlCommand(q, sqc);
                cmd.Parameters.AddWithValue("@UserId", s.UserId);

                if (sqc.State == ConnectionState.Open)
                {
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        success = true;
                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                sqc.Close();
            }
            return success;
        }

    }
}
