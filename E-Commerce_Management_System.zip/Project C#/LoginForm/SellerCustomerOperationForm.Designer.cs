﻿
namespace LoginForm
{
    partial class SellerCustomerOperationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerCustomerOperationForm));
            this.btnscofBack = new System.Windows.Forms.Button();
            this.gbscofGender = new System.Windows.Forms.GroupBox();
            this.rbscofgMale = new System.Windows.Forms.RadioButton();
            this.rbscofgFemale = new System.Windows.Forms.RadioButton();
            this.tbscofPassword = new System.Windows.Forms.TextBox();
            this.tbscofSecurityAns = new System.Windows.Forms.TextBox();
            this.tbscofAddress = new System.Windows.Forms.TextBox();
            this.tbscofAge = new System.Windows.Forms.TextBox();
            this.tbscofPhoneNo = new System.Windows.Forms.TextBox();
            this.tbscofEmail = new System.Windows.Forms.TextBox();
            this.tbscofName = new System.Windows.Forms.TextBox();
            this.tbscofUserId = new System.Windows.Forms.TextBox();
            this.lrPassword = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.dgvSellerCustomerOperation = new System.Windows.Forms.DataGridView();
            this.btnscofShow = new System.Windows.Forms.Button();
            this.btnscofAdd = new System.Windows.Forms.Button();
            this.dtpscofDoB = new System.Windows.Forms.DateTimePicker();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.searchBoxscof = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnscofDelete = new System.Windows.Forms.Button();
            this.btnscofUpdate = new System.Windows.Forms.Button();
            this.gbscofGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerCustomerOperation)).BeginInit();
            this.SuspendLayout();
            // 
            // btnscofBack
            // 
            this.btnscofBack.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnscofBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscofBack.Location = new System.Drawing.Point(743, 235);
            this.btnscofBack.Name = "btnscofBack";
            this.btnscofBack.Size = new System.Drawing.Size(75, 31);
            this.btnscofBack.TabIndex = 106;
            this.btnscofBack.Text = "Back";
            this.btnscofBack.UseVisualStyleBackColor = false;
            this.btnscofBack.Click += new System.EventHandler(this.btnscofBack_Click);
            // 
            // gbscofGender
            // 
            this.gbscofGender.BackColor = System.Drawing.Color.Moccasin;
            this.gbscofGender.Controls.Add(this.rbscofgMale);
            this.gbscofGender.Controls.Add(this.rbscofgFemale);
            this.gbscofGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbscofGender.Location = new System.Drawing.Point(466, 185);
            this.gbscofGender.Name = "gbscofGender";
            this.gbscofGender.Size = new System.Drawing.Size(284, 28);
            this.gbscofGender.TabIndex = 105;
            this.gbscofGender.TabStop = false;
            this.gbscofGender.Text = "Gender : ";
            // 
            // rbscofgMale
            // 
            this.rbscofgMale.AutoSize = true;
            this.rbscofgMale.BackColor = System.Drawing.Color.LightPink;
            this.rbscofgMale.Location = new System.Drawing.Point(83, 1);
            this.rbscofgMale.Name = "rbscofgMale";
            this.rbscofgMale.Size = new System.Drawing.Size(63, 24);
            this.rbscofgMale.TabIndex = 20;
            this.rbscofgMale.TabStop = true;
            this.rbscofgMale.Text = "Male";
            this.rbscofgMale.UseVisualStyleBackColor = false;
            this.rbscofgMale.CheckedChanged += new System.EventHandler(this.rbscofgMale_CheckedChanged);
            // 
            // rbscofgFemale
            // 
            this.rbscofgFemale.AutoSize = true;
            this.rbscofgFemale.BackColor = System.Drawing.Color.LightPink;
            this.rbscofgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbscofgFemale.Name = "rbscofgFemale";
            this.rbscofgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbscofgFemale.TabIndex = 21;
            this.rbscofgFemale.TabStop = true;
            this.rbscofgFemale.Text = "Female";
            this.rbscofgFemale.UseVisualStyleBackColor = false;
            this.rbscofgFemale.CheckedChanged += new System.EventHandler(this.rbscofgFemale_CheckedChanged);
            // 
            // tbscofPassword
            // 
            this.tbscofPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofPassword.Location = new System.Drawing.Point(570, 105);
            this.tbscofPassword.Name = "tbscofPassword";
            this.tbscofPassword.Size = new System.Drawing.Size(139, 26);
            this.tbscofPassword.TabIndex = 103;
            this.tbscofPassword.UseSystemPasswordChar = true;
            // 
            // tbscofSecurityAns
            // 
            this.tbscofSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofSecurityAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofSecurityAns.Location = new System.Drawing.Point(570, 68);
            this.tbscofSecurityAns.Name = "tbscofSecurityAns";
            this.tbscofSecurityAns.Size = new System.Drawing.Size(139, 26);
            this.tbscofSecurityAns.TabIndex = 102;
            // 
            // tbscofAddress
            // 
            this.tbscofAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofAddress.Location = new System.Drawing.Point(554, 8);
            this.tbscofAddress.Name = "tbscofAddress";
            this.tbscofAddress.Size = new System.Drawing.Size(139, 26);
            this.tbscofAddress.TabIndex = 101;
            // 
            // tbscofAge
            // 
            this.tbscofAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofAge.Location = new System.Drawing.Point(221, 181);
            this.tbscofAge.Name = "tbscofAge";
            this.tbscofAge.Size = new System.Drawing.Size(139, 26);
            this.tbscofAge.TabIndex = 100;
            // 
            // tbscofPhoneNo
            // 
            this.tbscofPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofPhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofPhoneNo.Location = new System.Drawing.Point(221, 143);
            this.tbscofPhoneNo.Name = "tbscofPhoneNo";
            this.tbscofPhoneNo.Size = new System.Drawing.Size(139, 26);
            this.tbscofPhoneNo.TabIndex = 99;
            // 
            // tbscofEmail
            // 
            this.tbscofEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofEmail.Location = new System.Drawing.Point(221, 102);
            this.tbscofEmail.Name = "tbscofEmail";
            this.tbscofEmail.Size = new System.Drawing.Size(139, 26);
            this.tbscofEmail.TabIndex = 98;
            // 
            // tbscofName
            // 
            this.tbscofName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofName.Location = new System.Drawing.Point(221, 64);
            this.tbscofName.Name = "tbscofName";
            this.tbscofName.Size = new System.Drawing.Size(139, 26);
            this.tbscofName.TabIndex = 97;
            // 
            // tbscofUserId
            // 
            this.tbscofUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbscofUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbscofUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbscofUserId.Location = new System.Drawing.Point(221, 24);
            this.tbscofUserId.Name = "tbscofUserId";
            this.tbscofUserId.Size = new System.Drawing.Size(139, 26);
            this.tbscofUserId.TabIndex = 96;
            // 
            // lrPassword
            // 
            this.lrPassword.AutoSize = true;
            this.lrPassword.BackColor = System.Drawing.Color.Transparent;
            this.lrPassword.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPassword.Location = new System.Drawing.Point(478, 108);
            this.lrPassword.Name = "lrPassword";
            this.lrPassword.Size = new System.Drawing.Size(90, 20);
            this.lrPassword.TabIndex = 94;
            this.lrPassword.Text = "Password : ";
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(430, 70);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 93;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(430, 41);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 92;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(474, 10);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 91;
            this.lrAddress.Text = "Address : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(171, 183);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 90;
            this.lrAge.Text = "Age : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(129, 146);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 89;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(163, 106);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 88;
            this.lrEmail.Text = "Email : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(158, 68);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 87;
            this.lrName.Text = "Name : ";
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(150, 27);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 86;
            this.lrUserId.Text = "User Id : ";
            // 
            // dgvSellerCustomerOperation
            // 
            this.dgvSellerCustomerOperation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvSellerCustomerOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSellerCustomerOperation.Location = new System.Drawing.Point(88, 282);
            this.dgvSellerCustomerOperation.Name = "dgvSellerCustomerOperation";
            this.dgvSellerCustomerOperation.Size = new System.Drawing.Size(752, 187);
            this.dgvSellerCustomerOperation.TabIndex = 107;
            this.dgvSellerCustomerOperation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSellerCustomerOperation_CellContentClick);
            this.dgvSellerCustomerOperation.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSellerCustomerOperation_RowHeaderMouseClick);
            // 
            // btnscofShow
            // 
            this.btnscofShow.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnscofShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscofShow.Location = new System.Drawing.Point(196, 235);
            this.btnscofShow.Name = "btnscofShow";
            this.btnscofShow.Size = new System.Drawing.Size(75, 31);
            this.btnscofShow.TabIndex = 109;
            this.btnscofShow.Text = "Show";
            this.btnscofShow.UseVisualStyleBackColor = false;
            this.btnscofShow.Click += new System.EventHandler(this.btnscofShow_Click);
            // 
            // btnscofAdd
            // 
            this.btnscofAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnscofAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscofAdd.Location = new System.Drawing.Point(103, 235);
            this.btnscofAdd.Name = "btnscofAdd";
            this.btnscofAdd.Size = new System.Drawing.Size(75, 31);
            this.btnscofAdd.TabIndex = 108;
            this.btnscofAdd.Text = "Add";
            this.btnscofAdd.UseVisualStyleBackColor = false;
            this.btnscofAdd.Click += new System.EventHandler(this.btnscofAdd_Click);
            // 
            // dtpscofDoB
            // 
            this.dtpscofDoB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpscofDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpscofDoB.Location = new System.Drawing.Point(570, 147);
            this.dtpscofDoB.Name = "dtpscofDoB";
            this.dtpscofDoB.Size = new System.Drawing.Size(239, 22);
            this.dtpscofDoB.TabIndex = 111;
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(455, 148);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(114, 20);
            this.lrAdminType.TabIndex = 110;
            this.lrAdminType.Text = "Date Of Birth : ";
            // 
            // searchBoxscof
            // 
            this.searchBoxscof.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchBoxscof.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBoxscof.ForeColor = System.Drawing.SystemColors.WindowText;
            this.searchBoxscof.Location = new System.Drawing.Point(554, 237);
            this.searchBoxscof.Name = "searchBoxscof";
            this.searchBoxscof.Size = new System.Drawing.Size(177, 26);
            this.searchBoxscof.TabIndex = 115;
            this.searchBoxscof.TextChanged += new System.EventHandler(this.searchBoxscof_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(481, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 114;
            this.label1.Text = "Search : ";
            // 
            // btnscofDelete
            // 
            this.btnscofDelete.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnscofDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscofDelete.Location = new System.Drawing.Point(377, 235);
            this.btnscofDelete.Name = "btnscofDelete";
            this.btnscofDelete.Size = new System.Drawing.Size(75, 31);
            this.btnscofDelete.TabIndex = 113;
            this.btnscofDelete.Text = "Delete";
            this.btnscofDelete.UseVisualStyleBackColor = false;
            this.btnscofDelete.Click += new System.EventHandler(this.btnscofDelete_Click);
            // 
            // btnscofUpdate
            // 
            this.btnscofUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnscofUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscofUpdate.Location = new System.Drawing.Point(282, 235);
            this.btnscofUpdate.Name = "btnscofUpdate";
            this.btnscofUpdate.Size = new System.Drawing.Size(75, 31);
            this.btnscofUpdate.TabIndex = 112;
            this.btnscofUpdate.Text = "Update";
            this.btnscofUpdate.UseVisualStyleBackColor = false;
            this.btnscofUpdate.Click += new System.EventHandler(this.btnscofUpdate_Click);
            // 
            // SellerCustomerOperationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(895, 484);
            this.Controls.Add(this.searchBoxscof);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnscofDelete);
            this.Controls.Add(this.btnscofUpdate);
            this.Controls.Add(this.dtpscofDoB);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.btnscofShow);
            this.Controls.Add(this.btnscofAdd);
            this.Controls.Add(this.dgvSellerCustomerOperation);
            this.Controls.Add(this.btnscofBack);
            this.Controls.Add(this.gbscofGender);
            this.Controls.Add(this.tbscofPassword);
            this.Controls.Add(this.tbscofSecurityAns);
            this.Controls.Add(this.tbscofAddress);
            this.Controls.Add(this.tbscofAge);
            this.Controls.Add(this.tbscofPhoneNo);
            this.Controls.Add(this.tbscofEmail);
            this.Controls.Add(this.tbscofName);
            this.Controls.Add(this.tbscofUserId);
            this.Controls.Add(this.lrPassword);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SellerCustomerOperationForm";
            this.Text = "SellerCustomerOperationForm";
            this.gbscofGender.ResumeLayout(false);
            this.gbscofGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerCustomerOperation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnscofBack;
        private System.Windows.Forms.GroupBox gbscofGender;
        private System.Windows.Forms.RadioButton rbscofgMale;
        private System.Windows.Forms.RadioButton rbscofgFemale;
        private System.Windows.Forms.TextBox tbscofPassword;
        private System.Windows.Forms.TextBox tbscofSecurityAns;
        private System.Windows.Forms.TextBox tbscofAddress;
        private System.Windows.Forms.TextBox tbscofAge;
        private System.Windows.Forms.TextBox tbscofPhoneNo;
        private System.Windows.Forms.TextBox tbscofEmail;
        private System.Windows.Forms.TextBox tbscofName;
        private System.Windows.Forms.TextBox tbscofUserId;
        private System.Windows.Forms.Label lrPassword;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.DataGridView dgvSellerCustomerOperation;
        private System.Windows.Forms.Button btnscofShow;
        private System.Windows.Forms.Button btnscofAdd;
        private System.Windows.Forms.DateTimePicker dtpscofDoB;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.TextBox searchBoxscof;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnscofDelete;
        private System.Windows.Forms.Button btnscofUpdate;
    }
}