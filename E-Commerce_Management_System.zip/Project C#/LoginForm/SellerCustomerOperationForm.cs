﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class SellerCustomerOperationForm : Form
    {
        public SellerCustomerOperationForm()
        {
            InitializeComponent();
        }

        Customer cs = new Customer();

        private void btnscofBack_Click(object sender, EventArgs e)
        {
            SellerHomeForm shf = new SellerHomeForm();
            shf.Show();
            this.Hide();
        }

        public void clear()
        {
            tbscofUserId.Clear();
            tbscofName.Clear();
            tbscofEmail.Clear();
            tbscofPhoneNo.Clear();
            tbscofAge.Clear();
            tbscofAddress.Clear();
            tbscofSecurityAns.Clear();
            tbscofPassword.Clear();
        }
        private void btnscofAdd_Click(object sender, EventArgs e)
        {
            try
            {
                cs.UserId = tbscofUserId.Text;
                cs.Name = tbscofName.Text;
                cs.Email = tbscofEmail.Text;
                cs.PhoneNo = tbscofPhoneNo.Text;
                cs.Age = Convert.ToInt32(tbscofAge.Text);
                cs.Address = tbscofAddress.Text;
                cs.SecurityAns = tbscofSecurityAns.Text;
                cs.Password = tbscofPassword.Text;
                cs.DoB = dtpscofDoB.Value.ToString();
            }
           catch (Exception c)
           {
               MessageBox.Show("Enter Valid Info");
           }
            bool success = cs.InsertCustomer(cs);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btnscofShow_Click(object sender, EventArgs e)
        {
            DataTable dt = cs.showAllCustomerList();
            dgvSellerCustomerOperation.DataSource = dt;
        }

        private void dgvSellerCustomerOperation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void rbscofgMale_CheckedChanged(object sender, EventArgs e)
        {
            cs.Gender = "Male";
        }

        private void rbscofgFemale_CheckedChanged(object sender, EventArgs e)
        {
            cs.Gender = "Female";
        }

        private void btnscofUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                cs.UserId = tbscofUserId.Text;
                cs.Name = tbscofName.Text;
                cs.Email = tbscofEmail.Text;
                cs.PhoneNo = tbscofPhoneNo.Text;
                cs.Age = Convert.ToInt32(tbscofAge.Text);
                cs.Address = tbscofAddress.Text;
                cs.SecurityAns = tbscofSecurityAns.Text;
                cs.Password = tbscofPassword.Text;
                cs.DoB = dtpscofDoB.Value.ToString();

                bool success = cs.updateCustomerOperation(cs);
                if (success == true)
                {
                    MessageBox.Show("Successfully Updated!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = cs.showAllCustomerList();
            dgvSellerCustomerOperation.DataSource = dt;
        }

        private void btnscofDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cs.UserId = tbscofUserId.Text;

                bool success = cs.deleteCustomerOperation(cs);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = cs.showAllCustomerList();
            dgvSellerCustomerOperation.DataSource = dt;
        }

        private void searchBoxscof_TextChanged(object sender, EventArgs e)
        {
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\CustomerOperation.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(connection);
            string q = "Select * From CustomerOperation Where Name Like '%" + searchBoxscof.Text + "%'";
            SqlDataAdapter sda = new SqlDataAdapter(q, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvSellerCustomerOperation.DataSource = dt;
        }

        private void dgvSellerCustomerOperation_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int row_index = e.RowIndex;
            tbscofUserId.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[0].Value.ToString();
            tbscofName.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[1].Value.ToString();
            tbscofEmail.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[2].Value.ToString();
            tbscofPhoneNo.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[3].Value.ToString();
            tbscofAge.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[4].Value.ToString();
            tbscofAddress.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[5].Value.ToString();
            tbscofSecurityAns.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[6].Value.ToString();
            tbscofPassword.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[7].Value.ToString();
            dtpscofDoB.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[8].Value.ToString();
            gbscofGender.Text = dgvSellerCustomerOperation.Rows[row_index].Cells[9].Value.ToString();
        }
    }
}
