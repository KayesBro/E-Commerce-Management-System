﻿
namespace LoginForm
{
    partial class SellerHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerHomeForm));
            this.btnshfCustomerOperation = new System.Windows.Forms.Button();
            this.btnshfViewAllProducts = new System.Windows.Forms.Button();
            this.btnshfViewAllOrders = new System.Windows.Forms.Button();
            this.btnshfAddProduct = new System.Windows.Forms.Button();
            this.btnshfLogOut = new System.Windows.Forms.Button();
            this.btnshfContact = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnshfCustomerOperation
            // 
            this.btnshfCustomerOperation.BackColor = System.Drawing.Color.Lime;
            this.btnshfCustomerOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfCustomerOperation.ForeColor = System.Drawing.Color.Black;
            this.btnshfCustomerOperation.Location = new System.Drawing.Point(12, 309);
            this.btnshfCustomerOperation.Name = "btnshfCustomerOperation";
            this.btnshfCustomerOperation.Size = new System.Drawing.Size(80, 36);
            this.btnshfCustomerOperation.TabIndex = 1;
            this.btnshfCustomerOperation.Text = "Customer Operation";
            this.btnshfCustomerOperation.UseVisualStyleBackColor = false;
            this.btnshfCustomerOperation.Click += new System.EventHandler(this.btnshfCustomerOperation_Click);
            // 
            // btnshfViewAllProducts
            // 
            this.btnshfViewAllProducts.BackColor = System.Drawing.Color.Lime;
            this.btnshfViewAllProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfViewAllProducts.ForeColor = System.Drawing.Color.Black;
            this.btnshfViewAllProducts.Location = new System.Drawing.Point(346, 76);
            this.btnshfViewAllProducts.Name = "btnshfViewAllProducts";
            this.btnshfViewAllProducts.Size = new System.Drawing.Size(80, 36);
            this.btnshfViewAllProducts.TabIndex = 3;
            this.btnshfViewAllProducts.Text = "View All Products";
            this.btnshfViewAllProducts.UseVisualStyleBackColor = false;
            this.btnshfViewAllProducts.Click += new System.EventHandler(this.btnshfViewAllProducts_Click);
            // 
            // btnshfViewAllOrders
            // 
            this.btnshfViewAllOrders.BackColor = System.Drawing.Color.Lime;
            this.btnshfViewAllOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfViewAllOrders.ForeColor = System.Drawing.Color.Black;
            this.btnshfViewAllOrders.Location = new System.Drawing.Point(665, 259);
            this.btnshfViewAllOrders.Name = "btnshfViewAllOrders";
            this.btnshfViewAllOrders.Size = new System.Drawing.Size(80, 36);
            this.btnshfViewAllOrders.TabIndex = 4;
            this.btnshfViewAllOrders.Text = "View All Orders";
            this.btnshfViewAllOrders.UseVisualStyleBackColor = false;
            this.btnshfViewAllOrders.Click += new System.EventHandler(this.btnshfViewAllOrders_Click);
            // 
            // btnshfAddProduct
            // 
            this.btnshfAddProduct.BackColor = System.Drawing.Color.Lime;
            this.btnshfAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfAddProduct.ForeColor = System.Drawing.Color.Black;
            this.btnshfAddProduct.Location = new System.Drawing.Point(119, 212);
            this.btnshfAddProduct.Name = "btnshfAddProduct";
            this.btnshfAddProduct.Size = new System.Drawing.Size(80, 36);
            this.btnshfAddProduct.TabIndex = 5;
            this.btnshfAddProduct.Text = "Add Products";
            this.btnshfAddProduct.UseVisualStyleBackColor = false;
            this.btnshfAddProduct.Click += new System.EventHandler(this.btnshfUpdatePassword_Click);
            // 
            // btnshfLogOut
            // 
            this.btnshfLogOut.BackColor = System.Drawing.Color.Lime;
            this.btnshfLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfLogOut.ForeColor = System.Drawing.Color.Black;
            this.btnshfLogOut.Location = new System.Drawing.Point(571, 151);
            this.btnshfLogOut.Name = "btnshfLogOut";
            this.btnshfLogOut.Size = new System.Drawing.Size(80, 36);
            this.btnshfLogOut.TabIndex = 6;
            this.btnshfLogOut.Text = "Log Out";
            this.btnshfLogOut.UseVisualStyleBackColor = false;
            this.btnshfLogOut.Click += new System.EventHandler(this.btnshfLogOut_Click);
            // 
            // btnshfContact
            // 
            this.btnshfContact.BackColor = System.Drawing.Color.Lime;
            this.btnshfContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfContact.ForeColor = System.Drawing.Color.Black;
            this.btnshfContact.Location = new System.Drawing.Point(704, 385);
            this.btnshfContact.Name = "btnshfContact";
            this.btnshfContact.Size = new System.Drawing.Size(66, 27);
            this.btnshfContact.TabIndex = 7;
            this.btnshfContact.Text = "Contact";
            this.btnshfContact.UseVisualStyleBackColor = false;
            this.btnshfContact.Click += new System.EventHandler(this.btnshfContact_Click);
            // 
            // SellerHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(782, 481);
            this.Controls.Add(this.btnshfContact);
            this.Controls.Add(this.btnshfLogOut);
            this.Controls.Add(this.btnshfAddProduct);
            this.Controls.Add(this.btnshfViewAllOrders);
            this.Controls.Add(this.btnshfViewAllProducts);
            this.Controls.Add(this.btnshfCustomerOperation);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SellerHomeForm";
            this.Text = "SellerHomeForm";
            this.Load += new System.EventHandler(this.SellerHomeForm_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnshfCustomerOperation;
        private System.Windows.Forms.Button btnshfViewAllProducts;
        private System.Windows.Forms.Button btnshfViewAllOrders;
        private System.Windows.Forms.Button btnshfAddProduct;
        private System.Windows.Forms.Button btnshfLogOut;
        private System.Windows.Forms.Button btnshfContact;
    }
}