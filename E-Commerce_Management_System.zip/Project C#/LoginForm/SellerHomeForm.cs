﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class SellerHomeForm : Form
    {
        public SellerHomeForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void SellerHomeForm_Load(object sender, EventArgs e)
        {

        }

        private void btnshfLogOut_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void btnshfCustomerOperation_Click(object sender, EventArgs e)
        {
            SellerCustomerOperationForm scof = new SellerCustomerOperationForm();
            scof.Show();
            this.Hide();
        }

        private void btnshfViewAllProducts_Click(object sender, EventArgs e)
        {
            SellerViewAllProductForm svapf = new SellerViewAllProductForm();
            svapf.Show();
            this.Hide();
        }

        private void btnshfViewAllOrders_Click(object sender, EventArgs e)
        {
            ViewOrderListshf o = new ViewOrderListshf();
            o.Show();
            this.Hide();
        }

        private void btnshfUpdatePassword_Click(object sender, EventArgs e)
        {
            AddProductshf add = new AddProductshf();
            add.Show();
            this.Hide();
        }

        private void btnshfContact_Click(object sender, EventArgs e)
        {
            MessageBox.Show("01603000591");
        }
    }
}
