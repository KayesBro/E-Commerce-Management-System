﻿
namespace LoginForm
{
    partial class SellerOperationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerOperationForm));
            this.gbsofGender = new System.Windows.Forms.GroupBox();
            this.rbsofgMale = new System.Windows.Forms.RadioButton();
            this.rbsofgFemale = new System.Windows.Forms.RadioButton();
            this.tbsofPassword = new System.Windows.Forms.TextBox();
            this.tbsofSecurityAns = new System.Windows.Forms.TextBox();
            this.tbsofAddress = new System.Windows.Forms.TextBox();
            this.tbsofAge = new System.Windows.Forms.TextBox();
            this.tbsofPhoneNo = new System.Windows.Forms.TextBox();
            this.tbsofEmail = new System.Windows.Forms.TextBox();
            this.tbsofName = new System.Windows.Forms.TextBox();
            this.tbsofUserId = new System.Windows.Forms.TextBox();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.lrPassword = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btnsofBack = new System.Windows.Forms.Button();
            this.dgvSellerOperation = new System.Windows.Forms.DataGridView();
            this.btnsofShow = new System.Windows.Forms.Button();
            this.btnsofAdd = new System.Windows.Forms.Button();
            this.dtpsofDoB = new System.Windows.Forms.DateTimePicker();
            this.searchBoxsof = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnsofDelete = new System.Windows.Forms.Button();
            this.btnsofUpdate = new System.Windows.Forms.Button();
            this.gbsofGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerOperation)).BeginInit();
            this.SuspendLayout();
            // 
            // gbsofGender
            // 
            this.gbsofGender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbsofGender.Controls.Add(this.rbsofgMale);
            this.gbsofGender.Controls.Add(this.rbsofgFemale);
            this.gbsofGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbsofGender.Location = new System.Drawing.Point(472, 187);
            this.gbsofGender.Name = "gbsofGender";
            this.gbsofGender.Size = new System.Drawing.Size(284, 28);
            this.gbsofGender.TabIndex = 64;
            this.gbsofGender.TabStop = false;
            this.gbsofGender.Text = "Gender : ";
            this.gbsofGender.Enter += new System.EventHandler(this.gbaofGender_Enter);
            // 
            // rbsofgMale
            // 
            this.rbsofgMale.AutoSize = true;
            this.rbsofgMale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.rbsofgMale.Location = new System.Drawing.Point(83, 1);
            this.rbsofgMale.Name = "rbsofgMale";
            this.rbsofgMale.Size = new System.Drawing.Size(63, 24);
            this.rbsofgMale.TabIndex = 20;
            this.rbsofgMale.TabStop = true;
            this.rbsofgMale.Text = "Male";
            this.rbsofgMale.UseVisualStyleBackColor = false;
            this.rbsofgMale.CheckedChanged += new System.EventHandler(this.rbaofgMale_CheckedChanged);
            // 
            // rbsofgFemale
            // 
            this.rbsofgFemale.AutoSize = true;
            this.rbsofgFemale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.rbsofgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbsofgFemale.Name = "rbsofgFemale";
            this.rbsofgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbsofgFemale.TabIndex = 21;
            this.rbsofgFemale.TabStop = true;
            this.rbsofgFemale.Text = "Female";
            this.rbsofgFemale.UseVisualStyleBackColor = false;
            this.rbsofgFemale.CheckedChanged += new System.EventHandler(this.rbsofgFemale_CheckedChanged);
            // 
            // tbsofPassword
            // 
            this.tbsofPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofPassword.Location = new System.Drawing.Point(576, 108);
            this.tbsofPassword.Name = "tbsofPassword";
            this.tbsofPassword.Size = new System.Drawing.Size(139, 26);
            this.tbsofPassword.TabIndex = 62;
            this.tbsofPassword.UseSystemPasswordChar = true;
            this.tbsofPassword.TextChanged += new System.EventHandler(this.tbaofPassword_TextChanged);
            // 
            // tbsofSecurityAns
            // 
            this.tbsofSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofSecurityAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofSecurityAns.Location = new System.Drawing.Point(576, 71);
            this.tbsofSecurityAns.Name = "tbsofSecurityAns";
            this.tbsofSecurityAns.Size = new System.Drawing.Size(139, 26);
            this.tbsofSecurityAns.TabIndex = 61;
            this.tbsofSecurityAns.TextChanged += new System.EventHandler(this.tbaofSecurityAns_TextChanged);
            // 
            // tbsofAddress
            // 
            this.tbsofAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofAddress.Location = new System.Drawing.Point(560, 9);
            this.tbsofAddress.Name = "tbsofAddress";
            this.tbsofAddress.Size = new System.Drawing.Size(139, 26);
            this.tbsofAddress.TabIndex = 60;
            // 
            // tbsofAge
            // 
            this.tbsofAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofAge.Location = new System.Drawing.Point(227, 182);
            this.tbsofAge.Name = "tbsofAge";
            this.tbsofAge.Size = new System.Drawing.Size(139, 26);
            this.tbsofAge.TabIndex = 59;
            this.tbsofAge.TextChanged += new System.EventHandler(this.tbaofAge_TextChanged);
            // 
            // tbsofPhoneNo
            // 
            this.tbsofPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofPhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofPhoneNo.Location = new System.Drawing.Point(227, 144);
            this.tbsofPhoneNo.Name = "tbsofPhoneNo";
            this.tbsofPhoneNo.Size = new System.Drawing.Size(139, 26);
            this.tbsofPhoneNo.TabIndex = 58;
            this.tbsofPhoneNo.TextChanged += new System.EventHandler(this.tbaofPhoneNo_TextChanged);
            // 
            // tbsofEmail
            // 
            this.tbsofEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofEmail.Location = new System.Drawing.Point(227, 104);
            this.tbsofEmail.Name = "tbsofEmail";
            this.tbsofEmail.Size = new System.Drawing.Size(139, 26);
            this.tbsofEmail.TabIndex = 57;
            this.tbsofEmail.TextChanged += new System.EventHandler(this.tbaofEmail_TextChanged);
            // 
            // tbsofName
            // 
            this.tbsofName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofName.Location = new System.Drawing.Point(227, 66);
            this.tbsofName.Name = "tbsofName";
            this.tbsofName.Size = new System.Drawing.Size(139, 26);
            this.tbsofName.TabIndex = 56;
            this.tbsofName.TextChanged += new System.EventHandler(this.tbaofName_TextChanged);
            // 
            // tbsofUserId
            // 
            this.tbsofUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbsofUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbsofUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbsofUserId.Location = new System.Drawing.Point(227, 24);
            this.tbsofUserId.Name = "tbsofUserId";
            this.tbsofUserId.Size = new System.Drawing.Size(139, 26);
            this.tbsofUserId.TabIndex = 55;
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(468, 148);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(114, 20);
            this.lrAdminType.TabIndex = 54;
            this.lrAdminType.Text = "Date Of Birth : ";
            this.lrAdminType.Click += new System.EventHandler(this.lrAdminType_Click);
            // 
            // lrPassword
            // 
            this.lrPassword.AutoSize = true;
            this.lrPassword.BackColor = System.Drawing.Color.Transparent;
            this.lrPassword.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPassword.Location = new System.Drawing.Point(484, 110);
            this.lrPassword.Name = "lrPassword";
            this.lrPassword.Size = new System.Drawing.Size(90, 20);
            this.lrPassword.TabIndex = 53;
            this.lrPassword.Text = "Password : ";
            this.lrPassword.Click += new System.EventHandler(this.lrPassword_Click);
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(436, 72);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 52;
            this.lrSecurityAns.Text = "Security Answer : ";
            this.lrSecurityAns.Click += new System.EventHandler(this.lrSecurityAns_Click);
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(436, 43);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 51;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            this.rityQuestion.Click += new System.EventHandler(this.rityQuestion_Click);
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(480, 12);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 50;
            this.lrAddress.Text = "Address : ";
            this.lrAddress.Click += new System.EventHandler(this.lrAddress_Click);
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(177, 185);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 49;
            this.lrAge.Text = "Age : ";
            this.lrAge.Click += new System.EventHandler(this.lrAge_Click);
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(135, 148);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 48;
            this.lrPhoneNo.Text = "Phone No : ";
            this.lrPhoneNo.Click += new System.EventHandler(this.lrPhoneNo_Click);
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(169, 108);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 47;
            this.lrEmail.Text = "Email : ";
            this.lrEmail.Click += new System.EventHandler(this.lrEmail_Click);
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(164, 70);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 46;
            this.lrName.Text = "Name : ";
            this.lrName.Click += new System.EventHandler(this.lrName_Click);
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(156, 29);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 45;
            this.lrUserId.Text = "User Id : ";
            this.lrUserId.Click += new System.EventHandler(this.lrUserId_Click);
            // 
            // btnsofBack
            // 
            this.btnsofBack.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsofBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsofBack.Location = new System.Drawing.Point(756, 233);
            this.btnsofBack.Name = "btnsofBack";
            this.btnsofBack.Size = new System.Drawing.Size(75, 31);
            this.btnsofBack.TabIndex = 65;
            this.btnsofBack.Text = "Back";
            this.btnsofBack.UseVisualStyleBackColor = false;
            this.btnsofBack.Click += new System.EventHandler(this.btnsofBack_Click);
            // 
            // dgvSellerOperation
            // 
            this.dgvSellerOperation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvSellerOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSellerOperation.Location = new System.Drawing.Point(79, 275);
            this.dgvSellerOperation.Name = "dgvSellerOperation";
            this.dgvSellerOperation.Size = new System.Drawing.Size(752, 187);
            this.dgvSellerOperation.TabIndex = 66;
            this.dgvSellerOperation.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSellerOperation_RowHeaderMouseClick);
            // 
            // btnsofShow
            // 
            this.btnsofShow.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsofShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsofShow.Location = new System.Drawing.Point(181, 233);
            this.btnsofShow.Name = "btnsofShow";
            this.btnsofShow.Size = new System.Drawing.Size(75, 31);
            this.btnsofShow.TabIndex = 68;
            this.btnsofShow.Text = "Show";
            this.btnsofShow.UseVisualStyleBackColor = false;
            this.btnsofShow.Click += new System.EventHandler(this.btnsofShow_Click);
            // 
            // btnsofAdd
            // 
            this.btnsofAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsofAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsofAdd.Location = new System.Drawing.Point(88, 233);
            this.btnsofAdd.Name = "btnsofAdd";
            this.btnsofAdd.Size = new System.Drawing.Size(75, 31);
            this.btnsofAdd.TabIndex = 67;
            this.btnsofAdd.Text = "Add";
            this.btnsofAdd.UseVisualStyleBackColor = false;
            this.btnsofAdd.Click += new System.EventHandler(this.btnsofAdd_Click);
            // 
            // dtpsofDoB
            // 
            this.dtpsofDoB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpsofDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpsofDoB.Location = new System.Drawing.Point(576, 146);
            this.dtpsofDoB.Name = "dtpsofDoB";
            this.dtpsofDoB.Size = new System.Drawing.Size(239, 22);
            this.dtpsofDoB.TabIndex = 69;
            // 
            // searchBoxsof
            // 
            this.searchBoxsof.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchBoxsof.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBoxsof.ForeColor = System.Drawing.SystemColors.WindowText;
            this.searchBoxsof.Location = new System.Drawing.Point(549, 235);
            this.searchBoxsof.Name = "searchBoxsof";
            this.searchBoxsof.Size = new System.Drawing.Size(177, 26);
            this.searchBoxsof.TabIndex = 73;
            this.searchBoxsof.TextChanged += new System.EventHandler(this.searchBoxsof_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(476, 239);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 72;
            this.label1.Text = "Search : ";
            // 
            // btnsofDelete
            // 
            this.btnsofDelete.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsofDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsofDelete.Location = new System.Drawing.Point(372, 233);
            this.btnsofDelete.Name = "btnsofDelete";
            this.btnsofDelete.Size = new System.Drawing.Size(75, 31);
            this.btnsofDelete.TabIndex = 71;
            this.btnsofDelete.Text = "Delete";
            this.btnsofDelete.UseVisualStyleBackColor = false;
            this.btnsofDelete.Click += new System.EventHandler(this.btnsofDelete_Click);
            // 
            // btnsofUpdate
            // 
            this.btnsofUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsofUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsofUpdate.Location = new System.Drawing.Point(277, 233);
            this.btnsofUpdate.Name = "btnsofUpdate";
            this.btnsofUpdate.Size = new System.Drawing.Size(75, 31);
            this.btnsofUpdate.TabIndex = 70;
            this.btnsofUpdate.Text = "Update";
            this.btnsofUpdate.UseVisualStyleBackColor = false;
            this.btnsofUpdate.Click += new System.EventHandler(this.btnsofUpdate_Click);
            // 
            // SellerOperationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(908, 509);
            this.Controls.Add(this.searchBoxsof);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsofDelete);
            this.Controls.Add(this.btnsofUpdate);
            this.Controls.Add(this.dtpsofDoB);
            this.Controls.Add(this.btnsofShow);
            this.Controls.Add(this.btnsofAdd);
            this.Controls.Add(this.dgvSellerOperation);
            this.Controls.Add(this.btnsofBack);
            this.Controls.Add(this.gbsofGender);
            this.Controls.Add(this.tbsofPassword);
            this.Controls.Add(this.tbsofSecurityAns);
            this.Controls.Add(this.tbsofAddress);
            this.Controls.Add(this.tbsofAge);
            this.Controls.Add(this.tbsofPhoneNo);
            this.Controls.Add(this.tbsofEmail);
            this.Controls.Add(this.tbsofName);
            this.Controls.Add(this.tbsofUserId);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.lrPassword);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SellerOperationForm";
            this.Text = "SellerOperationForm";
            this.Load += new System.EventHandler(this.SellerOperationForm_Load);
            this.gbsofGender.ResumeLayout(false);
            this.gbsofGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerOperation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbsofGender;
        private System.Windows.Forms.RadioButton rbsofgMale;
        private System.Windows.Forms.RadioButton rbsofgFemale;
        private System.Windows.Forms.TextBox tbsofPassword;
        private System.Windows.Forms.TextBox tbsofSecurityAns;
        private System.Windows.Forms.TextBox tbsofAddress;
        private System.Windows.Forms.TextBox tbsofAge;
        private System.Windows.Forms.TextBox tbsofPhoneNo;
        private System.Windows.Forms.TextBox tbsofEmail;
        private System.Windows.Forms.TextBox tbsofName;
        private System.Windows.Forms.TextBox tbsofUserId;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.Label lrPassword;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btnsofBack;
        private System.Windows.Forms.DataGridView dgvSellerOperation;
        private System.Windows.Forms.Button btnsofShow;
        private System.Windows.Forms.Button btnsofAdd;
        private System.Windows.Forms.DateTimePicker dtpsofDoB;
        private System.Windows.Forms.TextBox searchBoxsof;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnsofDelete;
        private System.Windows.Forms.Button btnsofUpdate;
    }
}