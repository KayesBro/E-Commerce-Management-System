﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class SellerOperationForm : Form
    {
        public SellerOperationForm()
        {
            InitializeComponent();
        }

        Seller se = new Seller();

        private void lrSecurityAns_Click(object sender, EventArgs e)
        {

        }

        private void tbaofAdminType_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofSecurityAns_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofPhoneNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbaofName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lrAdminType_Click(object sender, EventArgs e)
        {

        }

        private void lrPassword_Click(object sender, EventArgs e)
        {

        }

        private void gbaofGender_Enter(object sender, EventArgs e)
        {

        }

        private void rityQuestion_Click(object sender, EventArgs e)
        {

        }

        private void lrAddress_Click(object sender, EventArgs e)
        {

        }

        private void lrAge_Click(object sender, EventArgs e)
        {

        }

        private void lrPhoneNo_Click(object sender, EventArgs e)
        {

        }

        private void lrEmail_Click(object sender, EventArgs e)
        {

        }

        private void lrName_Click(object sender, EventArgs e)
        {

        }

        private void lrUserId_Click(object sender, EventArgs e)
        {

        }

        private void SellerOperationForm_Load(object sender, EventArgs e)
        {

        }

        private void rbaofgMale_CheckedChanged(object sender, EventArgs e)
        {
            se.Gender = "Male";
        }

        private void btnsofBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        public void clear()
        {
            tbsofUserId.Clear();
            tbsofName.Clear();
            tbsofEmail.Clear();
            tbsofPhoneNo.Clear();
            tbsofAge.Clear();
            tbsofAddress.Clear();
            tbsofSecurityAns.Clear();
            tbsofPassword.Clear();
        }

        private void btnsofAdd_Click(object sender, EventArgs e)
        {
            try
            {
                se.UserId = tbsofUserId.Text;
                se.Name = tbsofName.Text;
                se.Email = tbsofEmail.Text;
                se.PhoneNo = tbsofPhoneNo.Text;
                se.Age = Convert.ToInt32(tbsofAge.Text);
                se.Address = tbsofAddress.Text;
                se.SecurityAns = tbsofSecurityAns.Text;
                se.Password = tbsofPassword.Text;
                se.DoB = dtpsofDoB.Value.ToString();
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            bool success = se.InsertSeller(se);
            if (success == true)
            {
                MessageBox.Show("Successfully Added!!");
                clear();
            }
            else
            {
                MessageBox.Show("Failed!! TryAgain");
            }
        }

        private void btnsofShow_Click(object sender, EventArgs e)
        {
            DataTable dt = se.showAllSellerList();
            dgvSellerOperation.DataSource = dt;
        }

        private void rbsofgFemale_CheckedChanged(object sender, EventArgs e)
        {
            se.Gender = "Female";
        }

        private void btnsofUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                se.UserId = tbsofUserId.Text;
                se.Name = tbsofName.Text;
                se.Email = tbsofEmail.Text;
                se.PhoneNo = tbsofPhoneNo.Text;
                se.Age = Convert.ToInt32(tbsofAge.Text);
                se.Address = tbsofAddress.Text;
                se.SecurityAns = tbsofSecurityAns.Text;
                se.Password = tbsofPassword.Text;  
                se.DoB = dtpsofDoB.Value.ToString();

                bool success = se.updateSellerOperation(se);
                if (success == true)
                {
                    MessageBox.Show("Successfully Updated!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
           }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = se.showAllSellerList();
            dgvSellerOperation.DataSource = dt;
        }

        private void dgvSellerOperation_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int row_index = e.RowIndex;
            tbsofUserId.Text = dgvSellerOperation.Rows[row_index].Cells[0].Value.ToString();
            tbsofName.Text = dgvSellerOperation.Rows[row_index].Cells[1].Value.ToString();
            tbsofEmail.Text = dgvSellerOperation.Rows[row_index].Cells[2].Value.ToString();
            tbsofPhoneNo.Text = dgvSellerOperation.Rows[row_index].Cells[3].Value.ToString();
            tbsofAge.Text = dgvSellerOperation.Rows[row_index].Cells[4].Value.ToString();
            tbsofAddress.Text = dgvSellerOperation.Rows[row_index].Cells[5].Value.ToString();
            tbsofSecurityAns.Text = dgvSellerOperation.Rows[row_index].Cells[6].Value.ToString();
            tbsofPassword.Text = dgvSellerOperation.Rows[row_index].Cells[7].Value.ToString();
            dtpsofDoB.Text = dgvSellerOperation.Rows[row_index].Cells[8].Value.ToString();
            gbsofGender.Text = dgvSellerOperation.Rows[row_index].Cells[9].Value.ToString();
        }

        private void btnsofDelete_Click(object sender, EventArgs e)
        {
            try
            {
                se.UserId = tbsofUserId.Text;

                bool success = se.deleteSellerOperation(se);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = se.showAllSellerList();
            dgvSellerOperation.DataSource = dt;
        }

        private void searchBoxsof_TextChanged(object sender, EventArgs e)
        {
            string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\SellerOperation.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection conn = new SqlConnection(connection);
            string q = "Select * From SellerOperation Where Name Like '%" + searchBoxsof.Text + "%'";
            SqlDataAdapter sda = new SqlDataAdapter(q, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvSellerOperation.DataSource = dt;
        }
    }
}
