﻿
namespace LoginForm
{
    partial class SellerViewAllProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerViewAllProductForm));
            this.btnsvapfShow = new System.Windows.Forms.Button();
            this.dgvSellerViewAllProduct = new System.Windows.Forms.DataGridView();
            this.btnsvapf = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerViewAllProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // btnsvapfShow
            // 
            this.btnsvapfShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnsvapfShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsvapfShow.ForeColor = System.Drawing.Color.Black;
            this.btnsvapfShow.Location = new System.Drawing.Point(626, 7);
            this.btnsvapfShow.Name = "btnsvapfShow";
            this.btnsvapfShow.Size = new System.Drawing.Size(90, 40);
            this.btnsvapfShow.TabIndex = 7;
            this.btnsvapfShow.Text = "Show";
            this.btnsvapfShow.UseVisualStyleBackColor = false;
            this.btnsvapfShow.Click += new System.EventHandler(this.btnsvapfShow_Click);
            // 
            // dgvSellerViewAllProduct
            // 
            this.dgvSellerViewAllProduct.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvSellerViewAllProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSellerViewAllProduct.Location = new System.Drawing.Point(12, 56);
            this.dgvSellerViewAllProduct.Name = "dgvSellerViewAllProduct";
            this.dgvSellerViewAllProduct.Size = new System.Drawing.Size(855, 419);
            this.dgvSellerViewAllProduct.TabIndex = 5;
            // 
            // btnsvapf
            // 
            this.btnsvapf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnsvapf.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsvapf.ForeColor = System.Drawing.Color.Black;
            this.btnsvapf.Location = new System.Drawing.Point(760, 7);
            this.btnsvapf.Name = "btnsvapf";
            this.btnsvapf.Size = new System.Drawing.Size(90, 40);
            this.btnsvapf.TabIndex = 8;
            this.btnsvapf.Text = "Back";
            this.btnsvapf.UseVisualStyleBackColor = false;
            this.btnsvapf.Click += new System.EventHandler(this.btnsvapf_Click);
            // 
            // SellerViewAllProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(876, 479);
            this.Controls.Add(this.btnsvapf);
            this.Controls.Add(this.btnsvapfShow);
            this.Controls.Add(this.dgvSellerViewAllProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SellerViewAllProductForm";
            this.Text = "SellerViewAllProductForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSellerViewAllProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnsvapfShow;
        private System.Windows.Forms.DataGridView dgvSellerViewAllProduct;
        private System.Windows.Forms.Button btnsvapf;
    }
}