﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace LoginForm
{
    public partial class SellerViewAllProductForm : Form
    {
        public SellerViewAllProductForm()
        {
            InitializeComponent();
        }
        Product ss = new Product();

        private void btnsvapfShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ss.showAllProduct();
            dgvSellerViewAllProduct.DataSource = dt;
        }

        private void btnsvapf_Click(object sender, EventArgs e)
        {
            SellerHomeForm shf1 = new SellerHomeForm();
            shf1.Show();
            this.Hide();
        }
    }
}
