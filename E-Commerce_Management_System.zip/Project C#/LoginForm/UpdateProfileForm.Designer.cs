﻿
namespace LoginForm
{
    partial class UpdateProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateProfileForm));
            this.gbupfGender = new System.Windows.Forms.GroupBox();
            this.rbupfgMale = new System.Windows.Forms.RadioButton();
            this.rbupfgFemale = new System.Windows.Forms.RadioButton();
            this.tbupfAdminType = new System.Windows.Forms.TextBox();
            this.tbupfSecurityAns = new System.Windows.Forms.TextBox();
            this.tbrAddress = new System.Windows.Forms.TextBox();
            this.tbupfAge = new System.Windows.Forms.TextBox();
            this.tbupfPhoneNo = new System.Windows.Forms.TextBox();
            this.tbupfEmail = new System.Windows.Forms.TextBox();
            this.tbupfName = new System.Windows.Forms.TextBox();
            this.tbupfUserId = new System.Windows.Forms.TextBox();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btnupfUpdate = new System.Windows.Forms.Button();
            this.btnupfBack = new System.Windows.Forms.Button();
            this.gbupfGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbupfGender
            // 
            this.gbupfGender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gbupfGender.Controls.Add(this.rbupfgMale);
            this.gbupfGender.Controls.Add(this.rbupfgFemale);
            this.gbupfGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbupfGender.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gbupfGender.Location = new System.Drawing.Point(425, 352);
            this.gbupfGender.Name = "gbupfGender";
            this.gbupfGender.Size = new System.Drawing.Size(284, 28);
            this.gbupfGender.TabIndex = 44;
            this.gbupfGender.TabStop = false;
            this.gbupfGender.Text = "Gender : ";
            // 
            // rbupfgMale
            // 
            this.rbupfgMale.AutoSize = true;
            this.rbupfgMale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.rbupfgMale.Location = new System.Drawing.Point(83, 1);
            this.rbupfgMale.Name = "rbupfgMale";
            this.rbupfgMale.Size = new System.Drawing.Size(63, 24);
            this.rbupfgMale.TabIndex = 20;
            this.rbupfgMale.TabStop = true;
            this.rbupfgMale.Text = "Male";
            this.rbupfgMale.UseVisualStyleBackColor = false;
            // 
            // rbupfgFemale
            // 
            this.rbupfgFemale.AutoSize = true;
            this.rbupfgFemale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.rbupfgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbupfgFemale.Name = "rbupfgFemale";
            this.rbupfgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbupfgFemale.TabIndex = 21;
            this.rbupfgFemale.TabStop = true;
            this.rbupfgFemale.Text = "Female";
            this.rbupfgFemale.UseVisualStyleBackColor = false;
            // 
            // tbupfAdminType
            // 
            this.tbupfAdminType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfAdminType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfAdminType.Location = new System.Drawing.Point(529, 315);
            this.tbupfAdminType.Name = "tbupfAdminType";
            this.tbupfAdminType.Size = new System.Drawing.Size(139, 20);
            this.tbupfAdminType.TabIndex = 43;
            // 
            // tbupfSecurityAns
            // 
            this.tbupfSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfSecurityAns.Location = new System.Drawing.Point(529, 271);
            this.tbupfSecurityAns.Name = "tbupfSecurityAns";
            this.tbupfSecurityAns.Size = new System.Drawing.Size(139, 20);
            this.tbupfSecurityAns.TabIndex = 41;
            // 
            // tbrAddress
            // 
            this.tbrAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbrAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbrAddress.Location = new System.Drawing.Point(529, 207);
            this.tbrAddress.Name = "tbrAddress";
            this.tbrAddress.Size = new System.Drawing.Size(139, 20);
            this.tbrAddress.TabIndex = 40;
            // 
            // tbupfAge
            // 
            this.tbupfAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfAge.Location = new System.Drawing.Point(529, 167);
            this.tbupfAge.Name = "tbupfAge";
            this.tbupfAge.Size = new System.Drawing.Size(139, 20);
            this.tbupfAge.TabIndex = 39;
            // 
            // tbupfPhoneNo
            // 
            this.tbupfPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfPhoneNo.Location = new System.Drawing.Point(529, 130);
            this.tbupfPhoneNo.Name = "tbupfPhoneNo";
            this.tbupfPhoneNo.Size = new System.Drawing.Size(139, 20);
            this.tbupfPhoneNo.TabIndex = 38;
            // 
            // tbupfEmail
            // 
            this.tbupfEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfEmail.Location = new System.Drawing.Point(529, 88);
            this.tbupfEmail.Name = "tbupfEmail";
            this.tbupfEmail.Size = new System.Drawing.Size(139, 20);
            this.tbupfEmail.TabIndex = 37;
            // 
            // tbupfName
            // 
            this.tbupfName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfName.Location = new System.Drawing.Point(529, 52);
            this.tbupfName.Name = "tbupfName";
            this.tbupfName.Size = new System.Drawing.Size(139, 20);
            this.tbupfName.TabIndex = 36;
            // 
            // tbupfUserId
            // 
            this.tbupfUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupfUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupfUserId.Location = new System.Drawing.Point(529, 10);
            this.tbupfUserId.Name = "tbupfUserId";
            this.tbupfUserId.Size = new System.Drawing.Size(139, 20);
            this.tbupfUserId.TabIndex = 35;
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(421, 313);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(109, 20);
            this.lrAdminType.TabIndex = 34;
            this.lrAdminType.Text = "Admin Type : ";
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(389, 269);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 32;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(389, 244);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 31;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(449, 205);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 30;
            this.lrAddress.Text = "Address : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(479, 165);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 29;
            this.lrAge.Text = "Age : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(437, 128);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 28;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(471, 88);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 27;
            this.lrEmail.Text = "Email : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(466, 50);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 26;
            this.lrName.Text = "Name : ";
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(458, 9);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 25;
            this.lrUserId.Text = "User Id : ";
            // 
            // btnupfUpdate
            // 
            this.btnupfUpdate.BackColor = System.Drawing.Color.Lime;
            this.btnupfUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupfUpdate.Location = new System.Drawing.Point(425, 415);
            this.btnupfUpdate.Name = "btnupfUpdate";
            this.btnupfUpdate.Size = new System.Drawing.Size(86, 36);
            this.btnupfUpdate.TabIndex = 45;
            this.btnupfUpdate.Text = "Update";
            this.btnupfUpdate.UseVisualStyleBackColor = false;
            // 
            // btnupfBack
            // 
            this.btnupfBack.BackColor = System.Drawing.Color.Lime;
            this.btnupfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupfBack.Location = new System.Drawing.Point(597, 415);
            this.btnupfBack.Name = "btnupfBack";
            this.btnupfBack.Size = new System.Drawing.Size(86, 36);
            this.btnupfBack.TabIndex = 46;
            this.btnupfBack.Text = "Back";
            this.btnupfBack.UseVisualStyleBackColor = false;
            // 
            // UpdateProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(886, 505);
            this.Controls.Add(this.btnupfBack);
            this.Controls.Add(this.btnupfUpdate);
            this.Controls.Add(this.gbupfGender);
            this.Controls.Add(this.tbupfAdminType);
            this.Controls.Add(this.tbupfSecurityAns);
            this.Controls.Add(this.tbrAddress);
            this.Controls.Add(this.tbupfAge);
            this.Controls.Add(this.tbupfPhoneNo);
            this.Controls.Add(this.tbupfEmail);
            this.Controls.Add(this.tbupfName);
            this.Controls.Add(this.tbupfUserId);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdateProfileForm";
            this.Text = "UpdateProfileForm";
            this.gbupfGender.ResumeLayout(false);
            this.gbupfGender.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbupfGender;
        private System.Windows.Forms.RadioButton rbupfgMale;
        private System.Windows.Forms.RadioButton rbupfgFemale;
        private System.Windows.Forms.TextBox tbupfAdminType;
        private System.Windows.Forms.TextBox tbupfSecurityAns;
        private System.Windows.Forms.TextBox tbrAddress;
        private System.Windows.Forms.TextBox tbupfAge;
        private System.Windows.Forms.TextBox tbupfPhoneNo;
        private System.Windows.Forms.TextBox tbupfEmail;
        private System.Windows.Forms.TextBox tbupfName;
        private System.Windows.Forms.TextBox tbupfUserId;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btnupfUpdate;
        private System.Windows.Forms.Button btnupfBack;
    }
}