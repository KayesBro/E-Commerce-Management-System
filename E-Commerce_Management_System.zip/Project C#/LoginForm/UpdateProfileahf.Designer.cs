﻿
namespace LoginForm
{
    partial class UpdateProfileahf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateProfileahf));
            this.dtpaofDoB = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.gbupahfGender = new System.Windows.Forms.GroupBox();
            this.rbupahfgMale = new System.Windows.Forms.RadioButton();
            this.rbupahfgFemale = new System.Windows.Forms.RadioButton();
            this.tbupahfAdminType = new System.Windows.Forms.TextBox();
            this.tbupahfSecurityAns = new System.Windows.Forms.TextBox();
            this.tbupahfAddress = new System.Windows.Forms.TextBox();
            this.tbupahfAge = new System.Windows.Forms.TextBox();
            this.tbupahfPhoneNo = new System.Windows.Forms.TextBox();
            this.tbupahfEmail = new System.Windows.Forms.TextBox();
            this.tbupahfName = new System.Windows.Forms.TextBox();
            this.tbupahfUserId = new System.Windows.Forms.TextBox();
            this.lrAdminType = new System.Windows.Forms.Label();
            this.lrSecurityAns = new System.Windows.Forms.Label();
            this.rityQuestion = new System.Windows.Forms.Label();
            this.lrAddress = new System.Windows.Forms.Label();
            this.lrAge = new System.Windows.Forms.Label();
            this.lrPhoneNo = new System.Windows.Forms.Label();
            this.lrEmail = new System.Windows.Forms.Label();
            this.lrName = new System.Windows.Forms.Label();
            this.lrUserId = new System.Windows.Forms.Label();
            this.btnupahfUpdate = new System.Windows.Forms.Button();
            this.btnupahfBack = new System.Windows.Forms.Button();
            this.btnupahfShow = new System.Windows.Forms.Button();
            this.gbupahfGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpaofDoB
            // 
            this.dtpaofDoB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpaofDoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpaofDoB.Location = new System.Drawing.Point(196, 242);
            this.dtpaofDoB.Name = "dtpaofDoB";
            this.dtpaofDoB.Size = new System.Drawing.Size(239, 22);
            this.dtpaofDoB.TabIndex = 76;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(83, 242);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 75;
            this.label2.Text = "Date Of Birth : ";
            // 
            // gbupahfGender
            // 
            this.gbupahfGender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbupahfGender.Controls.Add(this.rbupahfgMale);
            this.gbupahfGender.Controls.Add(this.rbupahfgFemale);
            this.gbupahfGender.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbupahfGender.Location = new System.Drawing.Point(441, 191);
            this.gbupahfGender.Name = "gbupahfGender";
            this.gbupahfGender.Size = new System.Drawing.Size(284, 28);
            this.gbupahfGender.TabIndex = 74;
            this.gbupahfGender.TabStop = false;
            this.gbupahfGender.Text = "Gender : ";
            // 
            // rbupahfgMale
            // 
            this.rbupahfgMale.AutoSize = true;
            this.rbupahfgMale.BackColor = System.Drawing.Color.LightPink;
            this.rbupahfgMale.Location = new System.Drawing.Point(83, 1);
            this.rbupahfgMale.Name = "rbupahfgMale";
            this.rbupahfgMale.Size = new System.Drawing.Size(63, 24);
            this.rbupahfgMale.TabIndex = 20;
            this.rbupahfgMale.TabStop = true;
            this.rbupahfgMale.Text = "Male";
            this.rbupahfgMale.UseVisualStyleBackColor = false;
            // 
            // rbupahfgFemale
            // 
            this.rbupahfgFemale.AutoSize = true;
            this.rbupahfgFemale.BackColor = System.Drawing.Color.LightPink;
            this.rbupahfgFemale.Location = new System.Drawing.Point(179, 2);
            this.rbupahfgFemale.Name = "rbupahfgFemale";
            this.rbupahfgFemale.Size = new System.Drawing.Size(79, 24);
            this.rbupahfgFemale.TabIndex = 21;
            this.rbupahfgFemale.TabStop = true;
            this.rbupahfgFemale.Text = "Female";
            this.rbupahfgFemale.UseVisualStyleBackColor = false;
            // 
            // tbupahfAdminType
            // 
            this.tbupahfAdminType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfAdminType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfAdminType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfAdminType.Location = new System.Drawing.Point(545, 151);
            this.tbupahfAdminType.Name = "tbupahfAdminType";
            this.tbupahfAdminType.Size = new System.Drawing.Size(139, 26);
            this.tbupahfAdminType.TabIndex = 73;
            // 
            // tbupahfSecurityAns
            // 
            this.tbupahfSecurityAns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfSecurityAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfSecurityAns.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfSecurityAns.Location = new System.Drawing.Point(545, 103);
            this.tbupahfSecurityAns.Name = "tbupahfSecurityAns";
            this.tbupahfSecurityAns.Size = new System.Drawing.Size(139, 26);
            this.tbupahfSecurityAns.TabIndex = 71;
            // 
            // tbupahfAddress
            // 
            this.tbupahfAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfAddress.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfAddress.Location = new System.Drawing.Point(529, 42);
            this.tbupahfAddress.Name = "tbupahfAddress";
            this.tbupahfAddress.Size = new System.Drawing.Size(139, 26);
            this.tbupahfAddress.TabIndex = 70;
            // 
            // tbupahfAge
            // 
            this.tbupahfAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfAge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfAge.Location = new System.Drawing.Point(196, 198);
            this.tbupahfAge.Name = "tbupahfAge";
            this.tbupahfAge.Size = new System.Drawing.Size(139, 26);
            this.tbupahfAge.TabIndex = 69;
            // 
            // tbupahfPhoneNo
            // 
            this.tbupahfPhoneNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfPhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfPhoneNo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfPhoneNo.Location = new System.Drawing.Point(196, 161);
            this.tbupahfPhoneNo.Name = "tbupahfPhoneNo";
            this.tbupahfPhoneNo.Size = new System.Drawing.Size(139, 26);
            this.tbupahfPhoneNo.TabIndex = 68;
            // 
            // tbupahfEmail
            // 
            this.tbupahfEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfEmail.Location = new System.Drawing.Point(196, 119);
            this.tbupahfEmail.Name = "tbupahfEmail";
            this.tbupahfEmail.Size = new System.Drawing.Size(139, 26);
            this.tbupahfEmail.TabIndex = 67;
            // 
            // tbupahfName
            // 
            this.tbupahfName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfName.Location = new System.Drawing.Point(196, 83);
            this.tbupahfName.Name = "tbupahfName";
            this.tbupahfName.Size = new System.Drawing.Size(139, 26);
            this.tbupahfName.TabIndex = 66;
            // 
            // tbupahfUserId
            // 
            this.tbupahfUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbupahfUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbupahfUserId.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbupahfUserId.Location = new System.Drawing.Point(196, 41);
            this.tbupahfUserId.Name = "tbupahfUserId";
            this.tbupahfUserId.Size = new System.Drawing.Size(139, 26);
            this.tbupahfUserId.TabIndex = 65;
            this.tbupahfUserId.TextChanged += new System.EventHandler(this.tbupahfUserId_TextChanged);
            // 
            // lrAdminType
            // 
            this.lrAdminType.AutoSize = true;
            this.lrAdminType.BackColor = System.Drawing.Color.Transparent;
            this.lrAdminType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAdminType.Location = new System.Drawing.Point(437, 152);
            this.lrAdminType.Name = "lrAdminType";
            this.lrAdminType.Size = new System.Drawing.Size(109, 20);
            this.lrAdminType.TabIndex = 64;
            this.lrAdminType.Text = "Admin Type : ";
            // 
            // lrSecurityAns
            // 
            this.lrSecurityAns.AutoSize = true;
            this.lrSecurityAns.BackColor = System.Drawing.Color.Transparent;
            this.lrSecurityAns.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrSecurityAns.Location = new System.Drawing.Point(405, 105);
            this.lrSecurityAns.Name = "lrSecurityAns";
            this.lrSecurityAns.Size = new System.Drawing.Size(138, 20);
            this.lrSecurityAns.TabIndex = 62;
            this.lrSecurityAns.Text = "Security Answer : ";
            // 
            // rityQuestion
            // 
            this.rityQuestion.AutoSize = true;
            this.rityQuestion.BackColor = System.Drawing.Color.Transparent;
            this.rityQuestion.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rityQuestion.Location = new System.Drawing.Point(405, 76);
            this.rityQuestion.Name = "rityQuestion";
            this.rityQuestion.Size = new System.Drawing.Size(320, 20);
            this.rityQuestion.TabIndex = 61;
            this.rityQuestion.Text = "Security Question : What is your pet name?";
            // 
            // lrAddress
            // 
            this.lrAddress.AutoSize = true;
            this.lrAddress.BackColor = System.Drawing.Color.Transparent;
            this.lrAddress.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAddress.Location = new System.Drawing.Point(449, 45);
            this.lrAddress.Name = "lrAddress";
            this.lrAddress.Size = new System.Drawing.Size(81, 20);
            this.lrAddress.TabIndex = 60;
            this.lrAddress.Text = "Address : ";
            // 
            // lrAge
            // 
            this.lrAge.AutoSize = true;
            this.lrAge.BackColor = System.Drawing.Color.Transparent;
            this.lrAge.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrAge.Location = new System.Drawing.Point(146, 200);
            this.lrAge.Name = "lrAge";
            this.lrAge.Size = new System.Drawing.Size(51, 20);
            this.lrAge.TabIndex = 59;
            this.lrAge.Text = "Age : ";
            // 
            // lrPhoneNo
            // 
            this.lrPhoneNo.AutoSize = true;
            this.lrPhoneNo.BackColor = System.Drawing.Color.Transparent;
            this.lrPhoneNo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrPhoneNo.Location = new System.Drawing.Point(104, 163);
            this.lrPhoneNo.Name = "lrPhoneNo";
            this.lrPhoneNo.Size = new System.Drawing.Size(93, 20);
            this.lrPhoneNo.TabIndex = 58;
            this.lrPhoneNo.Text = "Phone No : ";
            // 
            // lrEmail
            // 
            this.lrEmail.AutoSize = true;
            this.lrEmail.BackColor = System.Drawing.Color.Transparent;
            this.lrEmail.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrEmail.Location = new System.Drawing.Point(138, 123);
            this.lrEmail.Name = "lrEmail";
            this.lrEmail.Size = new System.Drawing.Size(59, 20);
            this.lrEmail.TabIndex = 57;
            this.lrEmail.Text = "Email : ";
            // 
            // lrName
            // 
            this.lrName.AutoSize = true;
            this.lrName.BackColor = System.Drawing.Color.Transparent;
            this.lrName.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrName.Location = new System.Drawing.Point(133, 85);
            this.lrName.Name = "lrName";
            this.lrName.Size = new System.Drawing.Size(64, 20);
            this.lrName.TabIndex = 56;
            this.lrName.Text = "Name : ";
            // 
            // lrUserId
            // 
            this.lrUserId.AutoSize = true;
            this.lrUserId.BackColor = System.Drawing.Color.Transparent;
            this.lrUserId.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrUserId.Location = new System.Drawing.Point(125, 44);
            this.lrUserId.Name = "lrUserId";
            this.lrUserId.Size = new System.Drawing.Size(72, 20);
            this.lrUserId.TabIndex = 55;
            this.lrUserId.Text = "User Id : ";
            // 
            // btnupahfUpdate
            // 
            this.btnupahfUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnupahfUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupahfUpdate.Location = new System.Drawing.Point(545, 319);
            this.btnupahfUpdate.Name = "btnupahfUpdate";
            this.btnupahfUpdate.Size = new System.Drawing.Size(75, 31);
            this.btnupahfUpdate.TabIndex = 77;
            this.btnupahfUpdate.Text = "Update";
            this.btnupahfUpdate.UseVisualStyleBackColor = false;
            // 
            // btnupahfBack
            // 
            this.btnupahfBack.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnupahfBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupahfBack.Location = new System.Drawing.Point(650, 319);
            this.btnupahfBack.Name = "btnupahfBack";
            this.btnupahfBack.Size = new System.Drawing.Size(75, 31);
            this.btnupahfBack.TabIndex = 78;
            this.btnupahfBack.Text = "Back";
            this.btnupahfBack.UseVisualStyleBackColor = false;
            // 
            // btnupahfShow
            // 
            this.btnupahfShow.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnupahfShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupahfShow.Location = new System.Drawing.Point(453, 319);
            this.btnupahfShow.Name = "btnupahfShow";
            this.btnupahfShow.Size = new System.Drawing.Size(75, 31);
            this.btnupahfShow.TabIndex = 79;
            this.btnupahfShow.Text = "Show";
            this.btnupahfShow.UseVisualStyleBackColor = false;
            // 
            // UpdateProfileahf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(767, 407);
            this.Controls.Add(this.btnupahfShow);
            this.Controls.Add(this.btnupahfBack);
            this.Controls.Add(this.btnupahfUpdate);
            this.Controls.Add(this.dtpaofDoB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gbupahfGender);
            this.Controls.Add(this.tbupahfAdminType);
            this.Controls.Add(this.tbupahfSecurityAns);
            this.Controls.Add(this.tbupahfAddress);
            this.Controls.Add(this.tbupahfAge);
            this.Controls.Add(this.tbupahfPhoneNo);
            this.Controls.Add(this.tbupahfEmail);
            this.Controls.Add(this.tbupahfName);
            this.Controls.Add(this.tbupahfUserId);
            this.Controls.Add(this.lrAdminType);
            this.Controls.Add(this.lrSecurityAns);
            this.Controls.Add(this.rityQuestion);
            this.Controls.Add(this.lrAddress);
            this.Controls.Add(this.lrAge);
            this.Controls.Add(this.lrPhoneNo);
            this.Controls.Add(this.lrEmail);
            this.Controls.Add(this.lrName);
            this.Controls.Add(this.lrUserId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdateProfileahf";
            this.Text = "UpdateProfile";
            this.gbupahfGender.ResumeLayout(false);
            this.gbupahfGender.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpaofDoB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbupahfGender;
        private System.Windows.Forms.RadioButton rbupahfgMale;
        private System.Windows.Forms.RadioButton rbupahfgFemale;
        private System.Windows.Forms.TextBox tbupahfAdminType;
        private System.Windows.Forms.TextBox tbupahfSecurityAns;
        private System.Windows.Forms.TextBox tbupahfAddress;
        private System.Windows.Forms.TextBox tbupahfAge;
        private System.Windows.Forms.TextBox tbupahfPhoneNo;
        private System.Windows.Forms.TextBox tbupahfEmail;
        private System.Windows.Forms.TextBox tbupahfName;
        private System.Windows.Forms.TextBox tbupahfUserId;
        private System.Windows.Forms.Label lrAdminType;
        private System.Windows.Forms.Label lrSecurityAns;
        private System.Windows.Forms.Label rityQuestion;
        private System.Windows.Forms.Label lrAddress;
        private System.Windows.Forms.Label lrAge;
        private System.Windows.Forms.Label lrPhoneNo;
        private System.Windows.Forms.Label lrEmail;
        private System.Windows.Forms.Label lrName;
        private System.Windows.Forms.Label lrUserId;
        private System.Windows.Forms.Button btnupahfUpdate;
        private System.Windows.Forms.Button btnupahfBack;
        private System.Windows.Forms.Button btnupahfShow;
    }
}