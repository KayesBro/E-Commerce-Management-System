﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class UpdateProfileahf : Form
    {
        public UpdateProfileahf()
        {
            InitializeComponent();
        }

        private void tbupahfUserId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
