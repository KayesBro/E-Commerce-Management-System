﻿
namespace LoginForm
{
    partial class ViewCartProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewCartProduct));
            this.btnchfcartShow = new System.Windows.Forms.Button();
            this.btnchfcartBack = new System.Windows.Forms.Button();
            this.dgvchfCartProducts = new System.Windows.Forms.DataGridView();
            this.btnchfCartDelete = new System.Windows.Forms.Button();
            this.tbchfvcpDelete = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvchfCartProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // btnchfcartShow
            // 
            this.btnchfcartShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfcartShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfcartShow.ForeColor = System.Drawing.Color.Black;
            this.btnchfcartShow.Location = new System.Drawing.Point(227, 23);
            this.btnchfcartShow.Name = "btnchfcartShow";
            this.btnchfcartShow.Size = new System.Drawing.Size(90, 40);
            this.btnchfcartShow.TabIndex = 10;
            this.btnchfcartShow.Text = "Show";
            this.btnchfcartShow.UseVisualStyleBackColor = false;
            this.btnchfcartShow.Click += new System.EventHandler(this.btnchfcartShow_Click);
            // 
            // btnchfcartBack
            // 
            this.btnchfcartBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfcartBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfcartBack.ForeColor = System.Drawing.Color.Black;
            this.btnchfcartBack.Location = new System.Drawing.Point(350, 23);
            this.btnchfcartBack.Name = "btnchfcartBack";
            this.btnchfcartBack.Size = new System.Drawing.Size(90, 40);
            this.btnchfcartBack.TabIndex = 9;
            this.btnchfcartBack.Text = "Back";
            this.btnchfcartBack.UseVisualStyleBackColor = false;
            this.btnchfcartBack.Click += new System.EventHandler(this.btnchfcartBack_Click);
            // 
            // dgvchfCartProducts
            // 
            this.dgvchfCartProducts.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvchfCartProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvchfCartProducts.Location = new System.Drawing.Point(93, 140);
            this.dgvchfCartProducts.Name = "dgvchfCartProducts";
            this.dgvchfCartProducts.Size = new System.Drawing.Size(347, 364);
            this.dgvchfCartProducts.TabIndex = 8;
            // 
            // btnchfCartDelete
            // 
            this.btnchfCartDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnchfCartDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchfCartDelete.ForeColor = System.Drawing.Color.Black;
            this.btnchfCartDelete.Location = new System.Drawing.Point(352, 83);
            this.btnchfCartDelete.Name = "btnchfCartDelete";
            this.btnchfCartDelete.Size = new System.Drawing.Size(90, 40);
            this.btnchfCartDelete.TabIndex = 11;
            this.btnchfCartDelete.Text = "Delete";
            this.btnchfCartDelete.UseVisualStyleBackColor = false;
            this.btnchfCartDelete.Click += new System.EventHandler(this.btnchfCartDelete_Click);
            // 
            // tbchfvcpDelete
            // 
            this.tbchfvcpDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbchfvcpDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbchfvcpDelete.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbchfvcpDelete.Location = new System.Drawing.Point(205, 89);
            this.tbchfvcpDelete.Name = "tbchfvcpDelete";
            this.tbchfvcpDelete.Size = new System.Drawing.Size(139, 26);
            this.tbchfvcpDelete.TabIndex = 97;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 98;
            this.label4.Text = "Enter Product ID :";
            // 
            // ViewCartProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(479, 525);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbchfvcpDelete);
            this.Controls.Add(this.btnchfCartDelete);
            this.Controls.Add(this.btnchfcartShow);
            this.Controls.Add(this.btnchfcartBack);
            this.Controls.Add(this.dgvchfCartProducts);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewCartProduct";
            this.Text = "ViewCartProduct";
            this.Load += new System.EventHandler(this.ViewCartProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvchfCartProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnchfcartShow;
        private System.Windows.Forms.Button btnchfcartBack;
        private System.Windows.Forms.DataGridView dgvchfCartProducts;
        private System.Windows.Forms.Button btnchfCartDelete;
        private System.Windows.Forms.TextBox tbchfvcpDelete;
        private System.Windows.Forms.Label label4;
    }
}