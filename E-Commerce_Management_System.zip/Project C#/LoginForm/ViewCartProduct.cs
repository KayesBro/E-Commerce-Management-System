﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    public partial class ViewCartProduct : Form
    {
        public ViewCartProduct()
        {
            InitializeComponent();
        }
        CartList cl = new CartList();

        public void clear()
        {
            tbchfvcpDelete.Clear();
           
        }

        private void btnchfcartShow_Click(object sender, EventArgs e)
        {
            DataTable dt = cl.showAllCartList();
            dgvchfCartProducts.DataSource = dt;
        }

        private void btnchfcartBack_Click(object sender, EventArgs e)
        {
            CustomerHomeForm chf = new CustomerHomeForm();
            chf.Show();
            this.Hide();
        }

        private void ViewCartProduct_Load(object sender, EventArgs e)
        {

        }

        private void btnchfCartDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cl.ProductId = tbchfvcpDelete.Text;

                bool success = cl.deleteCart(cl);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = cl.showAllCartList();
            dgvchfCartProducts.DataSource = dt;
        }
    }
}
