﻿
namespace LoginForm
{
    partial class ViewOrderListahf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewOrderListahf));
            this.btnahfopsShow = new System.Windows.Forms.Button();
            this.btnahfopsBack = new System.Windows.Forms.Button();
            this.dgvahfOrderProducts = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.tbahfvcpDelete = new System.Windows.Forms.TextBox();
            this.btnahfCartDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvahfOrderProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // btnahfopsShow
            // 
            this.btnahfopsShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfopsShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfopsShow.ForeColor = System.Drawing.Color.Black;
            this.btnahfopsShow.Location = new System.Drawing.Point(420, 31);
            this.btnahfopsShow.Name = "btnahfopsShow";
            this.btnahfopsShow.Size = new System.Drawing.Size(90, 40);
            this.btnahfopsShow.TabIndex = 10;
            this.btnahfopsShow.Text = "Show";
            this.btnahfopsShow.UseVisualStyleBackColor = false;
            this.btnahfopsShow.Click += new System.EventHandler(this.btnahfopsShow_Click);
            // 
            // btnahfopsBack
            // 
            this.btnahfopsBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfopsBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfopsBack.ForeColor = System.Drawing.Color.Black;
            this.btnahfopsBack.Location = new System.Drawing.Point(538, 31);
            this.btnahfopsBack.Name = "btnahfopsBack";
            this.btnahfopsBack.Size = new System.Drawing.Size(90, 40);
            this.btnahfopsBack.TabIndex = 9;
            this.btnahfopsBack.Text = "Back";
            this.btnahfopsBack.UseVisualStyleBackColor = false;
            this.btnahfopsBack.Click += new System.EventHandler(this.btnahfopsBack_Click);
            // 
            // dgvahfOrderProducts
            // 
            this.dgvahfOrderProducts.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvahfOrderProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvahfOrderProducts.Location = new System.Drawing.Point(163, 156);
            this.dgvahfOrderProducts.Name = "dgvahfOrderProducts";
            this.dgvahfOrderProducts.Size = new System.Drawing.Size(465, 356);
            this.dgvahfOrderProducts.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(248, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 101;
            this.label4.Text = "Enter Product ID :";
            // 
            // tbahfvcpDelete
            // 
            this.tbahfvcpDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbahfvcpDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbahfvcpDelete.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbahfvcpDelete.Location = new System.Drawing.Point(390, 103);
            this.tbahfvcpDelete.Name = "tbahfvcpDelete";
            this.tbahfvcpDelete.Size = new System.Drawing.Size(139, 26);
            this.tbahfvcpDelete.TabIndex = 100;
            // 
            // btnahfCartDelete
            // 
            this.btnahfCartDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnahfCartDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnahfCartDelete.ForeColor = System.Drawing.Color.Black;
            this.btnahfCartDelete.Location = new System.Drawing.Point(537, 97);
            this.btnahfCartDelete.Name = "btnahfCartDelete";
            this.btnahfCartDelete.Size = new System.Drawing.Size(90, 40);
            this.btnahfCartDelete.TabIndex = 99;
            this.btnahfCartDelete.Text = "Delete";
            this.btnahfCartDelete.UseVisualStyleBackColor = false;
            this.btnahfCartDelete.Click += new System.EventHandler(this.btnahfCartDelete_Click);
            // 
            // ViewOrderListahf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(652, 529);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbahfvcpDelete);
            this.Controls.Add(this.btnahfCartDelete);
            this.Controls.Add(this.btnahfopsShow);
            this.Controls.Add(this.btnahfopsBack);
            this.Controls.Add(this.dgvahfOrderProducts);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewOrderListahf";
            this.Text = "ViewOrderListahf";
            ((System.ComponentModel.ISupportInitialize)(this.dgvahfOrderProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnahfopsShow;
        private System.Windows.Forms.Button btnahfopsBack;
        private System.Windows.Forms.DataGridView dgvahfOrderProducts;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbahfvcpDelete;
        private System.Windows.Forms.Button btnahfCartDelete;
    }
}