﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    public partial class ViewOrderListahf : Form
    {
        public ViewOrderListahf()
        {
            InitializeComponent();
        }
        OrderList ol = new OrderList();
        private void btnahfopsShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ol.showAllOrderList();
            dgvahfOrderProducts.DataSource = dt;
        }

        private void btnahfopsBack_Click(object sender, EventArgs e)
        {
            AdminHomeForm ahf = new AdminHomeForm();
            ahf.Show();
            this.Hide();
        }

        public void clear()
        {
            tbahfvcpDelete.Clear();

        }
        private void btnahfCartDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ol.ProductId = tbahfvcpDelete.Text;

                bool success = ol.deleteOrder(ol);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = ol.showAllOrderList();
            dgvahfOrderProducts.DataSource = dt;
        }
    }
}
