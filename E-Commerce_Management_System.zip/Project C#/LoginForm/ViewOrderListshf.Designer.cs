﻿
namespace LoginForm
{
    partial class ViewOrderListshf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewOrderListshf));
            this.label4 = new System.Windows.Forms.Label();
            this.tbshfvcpDelete = new System.Windows.Forms.TextBox();
            this.btnshfCartDelete = new System.Windows.Forms.Button();
            this.btnshfopsShow = new System.Windows.Forms.Button();
            this.btnshfopsBack = new System.Windows.Forms.Button();
            this.dgvshfOrderProducts = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvshfOrderProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(230, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 107;
            this.label4.Text = "Enter Product ID :";
            // 
            // tbshfvcpDelete
            // 
            this.tbshfvcpDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbshfvcpDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbshfvcpDelete.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbshfvcpDelete.Location = new System.Drawing.Point(372, 92);
            this.tbshfvcpDelete.Name = "tbshfvcpDelete";
            this.tbshfvcpDelete.Size = new System.Drawing.Size(139, 26);
            this.tbshfvcpDelete.TabIndex = 106;
            // 
            // btnshfCartDelete
            // 
            this.btnshfCartDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnshfCartDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfCartDelete.ForeColor = System.Drawing.Color.Black;
            this.btnshfCartDelete.Location = new System.Drawing.Point(519, 86);
            this.btnshfCartDelete.Name = "btnshfCartDelete";
            this.btnshfCartDelete.Size = new System.Drawing.Size(90, 40);
            this.btnshfCartDelete.TabIndex = 105;
            this.btnshfCartDelete.Text = "Delete";
            this.btnshfCartDelete.UseVisualStyleBackColor = false;
            this.btnshfCartDelete.Click += new System.EventHandler(this.btnshfCartDelete_Click);
            // 
            // btnshfopsShow
            // 
            this.btnshfopsShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnshfopsShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfopsShow.ForeColor = System.Drawing.Color.Black;
            this.btnshfopsShow.Location = new System.Drawing.Point(402, 20);
            this.btnshfopsShow.Name = "btnshfopsShow";
            this.btnshfopsShow.Size = new System.Drawing.Size(90, 40);
            this.btnshfopsShow.TabIndex = 104;
            this.btnshfopsShow.Text = "Show";
            this.btnshfopsShow.UseVisualStyleBackColor = false;
            this.btnshfopsShow.Click += new System.EventHandler(this.btnshfopsShow_Click);
            // 
            // btnshfopsBack
            // 
            this.btnshfopsBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnshfopsBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshfopsBack.ForeColor = System.Drawing.Color.Black;
            this.btnshfopsBack.Location = new System.Drawing.Point(520, 20);
            this.btnshfopsBack.Name = "btnshfopsBack";
            this.btnshfopsBack.Size = new System.Drawing.Size(90, 40);
            this.btnshfopsBack.TabIndex = 103;
            this.btnshfopsBack.Text = "Back";
            this.btnshfopsBack.UseVisualStyleBackColor = false;
            this.btnshfopsBack.Click += new System.EventHandler(this.btnshfopsBack_Click);
            // 
            // dgvshfOrderProducts
            // 
            this.dgvshfOrderProducts.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvshfOrderProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvshfOrderProducts.Location = new System.Drawing.Point(145, 145);
            this.dgvshfOrderProducts.Name = "dgvshfOrderProducts";
            this.dgvshfOrderProducts.Size = new System.Drawing.Size(465, 356);
            this.dgvshfOrderProducts.TabIndex = 102;
            // 
            // ViewOrderListshf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(647, 513);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbshfvcpDelete);
            this.Controls.Add(this.btnshfCartDelete);
            this.Controls.Add(this.btnshfopsShow);
            this.Controls.Add(this.btnshfopsBack);
            this.Controls.Add(this.dgvshfOrderProducts);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewOrderListshf";
            this.Text = "ViewOrderList";
            ((System.ComponentModel.ISupportInitialize)(this.dgvshfOrderProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbshfvcpDelete;
        private System.Windows.Forms.Button btnshfCartDelete;
        private System.Windows.Forms.Button btnshfopsShow;
        private System.Windows.Forms.Button btnshfopsBack;
        private System.Windows.Forms.DataGridView dgvshfOrderProducts;
    }
}