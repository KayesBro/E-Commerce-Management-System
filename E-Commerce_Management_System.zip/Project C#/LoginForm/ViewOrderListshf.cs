﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace LoginForm
{
    public partial class ViewOrderListshf : Form
    {
        public ViewOrderListshf()
        {
            InitializeComponent();
        }
        OrderList ol = new OrderList();

        private void btnshfopsShow_Click(object sender, EventArgs e)
        {
            DataTable dt = ol.showAllOrderList();
            dgvshfOrderProducts.DataSource = dt;
        }

        private void btnshfopsBack_Click(object sender, EventArgs e)
        {
            SellerHomeForm ahf = new SellerHomeForm();
            ahf.Show();
            this.Hide();
        }
        public void clear()
        {
            tbshfvcpDelete.Clear();

        }

        private void btnshfCartDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ol.ProductId = tbshfvcpDelete.Text;

                bool success = ol.deleteOrder(ol);
                if (success == true)
                {
                    MessageBox.Show("Successfully Deleted!!");
                    clear();
                }
                else
                {
                    MessageBox.Show("Failed!! TryAgain");
                }
            }
            catch (Exception c)
            {
                MessageBox.Show("Enter Valid Info");
            }
            DataTable dt = ol.showAllOrderList();
            dgvshfOrderProducts.DataSource = dt;
        }
    }
}
