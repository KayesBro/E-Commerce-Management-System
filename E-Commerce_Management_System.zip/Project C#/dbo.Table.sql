﻿CREATE TABLE [dbo].[AdminOperation]
(
	[UserId] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(10) NULL
)
